import { TridFeeItem } from '../types/mortgage';

/**
 * Calculates standard monthly mortgage payment for fixed-rate loan
 * Formula: P * [ r(1 + r)^n ] / [ (1 + r)^n – 1]
 */
export function calculateMonthlyPI(principal: number, annualInterestRatePercent: number, termMonths: number): number {
  if (principal <= 0 || termMonths <= 0) return 0;
  if (annualInterestRatePercent <= 0) return principal / termMonths;

  const monthlyRate = annualInterestRatePercent / 100 / 12;
  const factor = Math.pow(1 + monthlyRate, termMonths);
  const payment = principal * (monthlyRate * factor) / (factor - 1);
  return Math.round(payment * 100) / 100;
}

/**
 * Calculates monthly Private Mortgage Insurance (PMI) if LTV > 80%
 * Standard conventional PMI rates typically range between 0.3% - 1.2% annually depending on FICO and LTV.
 */
export function calculateMonthlyPMI(loanAmount: number, propertyValue: number, ficoScore: number): number {
  if (propertyValue <= 0 || loanAmount <= 0) return 0;
  const ltv = (loanAmount / propertyValue) * 100;
  if (ltv <= 80) return 0;

  // Tiered PMI factor estimate based on FICO
  let annualFactor = 0.0055;
  if (ficoScore >= 760) annualFactor = 0.0035;
  else if (ficoScore >= 720) annualFactor = 0.0048;
  else if (ficoScore >= 680) annualFactor = 0.0072;
  else annualFactor = 0.0098;

  if (ltv > 95) annualFactor += 0.0025;

  return Math.round((loanAmount * annualFactor) / 12);
}

/**
 * Calculates Front-End Debt-to-Income (Housing Ratio)
 */
export function calculateFrontEndDTI(monthlyHousingExpense: number, grossMonthlyIncome: number): number {
  if (grossMonthlyIncome <= 0) return 0;
  return Math.round((monthlyHousingExpense / grossMonthlyIncome) * 1000) / 10;
}

/**
 * Calculates Back-End Debt-to-Income (Total Debt Ratio)
 */
export function calculateBackEndDTI(monthlyHousingExpense: number, monthlyRecurringDebts: number, grossMonthlyIncome: number): number {
  if (grossMonthlyIncome <= 0) return 0;
  return Math.round(((monthlyHousingExpense + monthlyRecurringDebts) / grossMonthlyIncome) * 1000) / 10;
}

/**
 * Calculates Loan to Value (LTV)
 */
export function calculateLTV(loanAmount: number, propertyValue: number): number {
  if (propertyValue <= 0) return 0;
  return Math.round((loanAmount / propertyValue) * 1000) / 10;
}

export interface AmortizationRow {
  month: number;
  payment: number;
  principal: number;
  interest: number;
  totalInterestPaid: number;
  remainingBalance: number;
}

/**
 * Generates an amortization schedule, optionally with extra monthly principal
 */
export function generateAmortizationSchedule(
  principal: number,
  annualRate: number,
  termMonths: number,
  extraPrincipalMonthly: number = 0
): AmortizationRow[] {
  const schedule: AmortizationRow[] = [];
  const baseMonthlyPayment = calculateMonthlyPI(principal, annualRate, termMonths);
  const monthlyRate = annualRate / 100 / 12;

  let balance = principal;
  let totalInterest = 0;

  for (let month = 1; month <= termMonths; month++) {
    if (balance <= 0) break;

    const interestForMonth = balance * monthlyRate;
    let principalForMonth = baseMonthlyPayment - interestForMonth + extraPrincipalMonthly;

    if (principalForMonth > balance) {
      principalForMonth = balance;
    }

    balance -= principalForMonth;
    totalInterest += interestForMonth;

    schedule.push({
      month,
      payment: Math.round((principalForMonth + interestForMonth) * 100) / 100,
      principal: Math.round(principalForMonth * 100) / 100,
      interest: Math.round(interestForMonth * 100) / 100,
      totalInterestPaid: Math.round(totalInterest * 100) / 100,
      remainingBalance: Math.max(0, Math.round(balance * 100) / 100),
    });

    if (balance <= 0.01) break;
  }

  return schedule;
}

/**
 * TRID Tolerance Audit
 * 0% Tolerance: Origination charges, transfer taxes, affiliate fees. CD cannot exceed LE by a single cent.
 * 10% Tolerance: Settlement service providers selected from lender's shopping list. The sum total of all 10% items cannot exceed LE sum by > 10%.
 * Unlimited: Prepaid interest, homeowner insurance, property taxes, services borrower shopped on their own.
 */
export interface TridToleranceResult {
  zeroToleranceViolation: boolean;
  zeroToleranceOverage: number;
  tenPercentToleranceViolation: boolean;
  tenPercentTotalLE: number;
  tenPercentTotalCD: number;
  tenPercentAllowableLimit: number;
  tenPercentOverage: number;
  totalCureRequired: number;
  isCompliant: boolean;
}

export function evaluateTridTolerances(fees: TridFeeItem[]): TridToleranceResult {
  let zeroToleranceOverage = 0;
  let tenPercentTotalLE = 0;
  let tenPercentTotalCD = 0;

  for (const fee of fees) {
    if (fee.paidBy !== 'Borrower') continue;

    if (fee.toleranceCategory === 'zero') {
      const diff = fee.closingDisclosureAmount - fee.loanEstimateAmount;
      if (diff > 0) {
        zeroToleranceOverage += diff;
      }
    } else if (fee.toleranceCategory === 'ten_percent') {
      tenPercentTotalLE += fee.loanEstimateAmount;
      tenPercentTotalCD += fee.closingDisclosureAmount;
    }
  }

  const tenPercentAllowableLimit = tenPercentTotalLE * 1.10;
  const tenPercentOverage = Math.max(0, tenPercentTotalCD - tenPercentAllowableLimit);

  const zeroToleranceViolation = zeroToleranceOverage > 0;
  const tenPercentToleranceViolation = tenPercentOverage > 0;
  const totalCureRequired = Math.round((zeroToleranceOverage + tenPercentOverage) * 100) / 100;
  const isCompliant = totalCureRequired === 0;

  return {
    zeroToleranceViolation,
    zeroToleranceOverage: Math.round(zeroToleranceOverage * 100) / 100,
    tenPercentToleranceViolation,
    tenPercentTotalLE: Math.round(tenPercentTotalLE * 100) / 100,
    tenPercentTotalCD: Math.round(tenPercentTotalCD * 100) / 100,
    tenPercentAllowableLimit: Math.round(tenPercentAllowableLimit * 100) / 100,
    tenPercentOverage: Math.round(tenPercentOverage * 100) / 100,
    totalCureRequired,
    isCompliant,
  };
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatCurrencyPrecise(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatPercent(value: number): string {
  return `${value.toFixed(3)}%`;
}
