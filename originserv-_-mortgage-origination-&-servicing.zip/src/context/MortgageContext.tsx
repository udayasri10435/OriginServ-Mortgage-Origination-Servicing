import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  LoanApplication,
  UserRole,
  LoanStage,
  UnderwritingCondition,
  ServicingPaymentRecord,
} from '../types/mortgage';
import { INITIAL_LOANS } from '../data/mockLoans';
import { calculateMonthlyPI } from '../utils/mortgageMath';

interface MortgageContextType {
  loans: LoanApplication[];
  selectedLoanId: string | null;
  selectedLoan: LoanApplication | undefined;
  setSelectedLoanId: (id: string | null) => void;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  createLoan: (newLoan: LoanApplication) => void;
  updateLoan: (id: string, updates: Partial<LoanApplication>) => void;
  advanceStage: (id: string, nextStage: LoanStage) => void;
  runAUS: (id: string) => void;
  addCondition: (loanId: string, condition: Omit<UnderwritingCondition, 'id'>) => void;
  updateConditionStatus: (loanId: string, conditionId: string, status: UnderwritingCondition['status']) => void;
  updateTridFee: (loanId: string, feeId: string, leAmount: number, cdAmount: number) => void;
  issueClearToClose: (loanId: string) => void;
  fundAndTransferToServicing: (loanId: string) => void;
  recordServicingPayment: (loanId: string, amount: number, extraPrincipal?: number) => void;
  addLoanNote: (loanId: string, content: string) => void;
}

const MortgageContext = createContext<MortgageContextType | undefined>(undefined);

export const MortgageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [loans, setLoans] = useState<LoanApplication[]>(() => {
    const saved = localStorage.getItem('originserv_loans_db');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_LOANS;
      }
    }
    return INITIAL_LOANS;
  });

  const [selectedLoanId, setSelectedLoanId] = useState<string | null>('LN-2026-1049');
  const [currentRole, setCurrentRole] = useState<UserRole>('lender');
  const [currentTab, setCurrentTab] = useState<string>('pipeline');

  useEffect(() => {
    localStorage.setItem('originserv_loans_db', JSON.stringify(loans));
  }, [loans]);

  const selectedLoan = loans.find(l => l.id === selectedLoanId);

  const createLoan = (newLoan: LoanApplication) => {
    setLoans(prev => [newLoan, ...prev]);
    setSelectedLoanId(newLoan.id);
    setCurrentTab('underwriting');
  };

  const updateLoan = (id: string, updates: Partial<LoanApplication>) => {
    setLoans(prev =>
      prev.map(loan => {
        if (loan.id === id) {
          return {
            ...loan,
            ...updates,
            updatedAt: new Date().toISOString().split('T')[0],
          };
        }
        return loan;
      })
    );
  };

  const advanceStage = (id: string, nextStage: LoanStage) => {
    updateLoan(id, { stage: nextStage });
  };

  const runAUS = (id: string) => {
    const loan = loans.find(l => l.id === id);
    if (!loan) return;

    const housingExp = calculateMonthlyPI(loan.terms.loanAmount, loan.terms.interestRate, loan.terms.termMonths) +
      loan.property.annualPropertyTax / 12 +
      loan.property.annualHazardInsurance / 12 +
      loan.property.monthlyHOA;
    const totalDebt = housingExp + loan.borrower.monthlyDebts.reduce((sum, d) => sum + d.monthlyPayment, 0);
    const dti = (totalDebt / (loan.borrower.monthlyBaseIncome + loan.borrower.monthlyOtherIncome)) * 100;

    let rec: 'Approve/Eligible' | 'Refer/Eligible' | 'Refer/Ineligible' = 'Approve/Eligible';
    const findings: string[] = [];

    if (loan.borrower.ficoScore < 620) {
      rec = 'Refer/Ineligible';
      findings.push('FICO Score below standard agency minimum of 620.');
    } else if (dti > 50) {
      rec = 'Refer/Ineligible';
      findings.push(`Total Back-End DTI of ${dti.toFixed(1)}% exceeds maximum automated limit (50.0%). Manual underwrite required.`);
    } else if (dti > 45 || loan.borrower.ficoScore < 680) {
      rec = 'Refer/Eligible';
      findings.push(`Compensating factors required due to DTI (${dti.toFixed(1)}%) and credit score (${loan.borrower.ficoScore}).`);
    } else {
      findings.push('Automated underwriting Accept recommendation issued.');
      findings.push(`Reserves requirement: 2 months PITI verified. Total DTI: ${dti.toFixed(1)}%.`);
      findings.push('Standard appraisal and income verification documentation required.');
    }

    updateLoan(id, {
      aus: {
        system: loan.terms.loanType === 'FHA' ? 'Desktop Underwriter (DU)' : 'Loan Product Advisor (LPA)',
        recommendation: rec,
        runDate: new Date().toISOString().split('T')[0],
        caseFileId: `AUS-${Math.floor(100000 + Math.random() * 900000)}`,
        findings,
      },
    });
  };

  const addCondition = (loanId: string, condition: Omit<UnderwritingCondition, 'id'>) => {
    const newCond: UnderwritingCondition = {
      ...condition,
      id: `COND-${Date.now().toString().slice(-4)}`,
    };
    setLoans(prev =>
      prev.map(loan => {
        if (loan.id === loanId) {
          return {
            ...loan,
            conditions: [...loan.conditions, newCond],
          };
        }
        return loan;
      })
    );
  };

  const updateConditionStatus = (loanId: string, conditionId: string, status: UnderwritingCondition['status']) => {
    setLoans(prev =>
      prev.map(loan => {
        if (loan.id === loanId) {
          const updatedConditions = loan.conditions.map(c => {
            if (c.id === conditionId) {
              return {
                ...c,
                status,
                clearedBy: status === 'cleared' ? (currentRole === 'lender' ? 'Senior Underwriter' : 'Broker') : c.clearedBy,
                clearedAt: status === 'cleared' ? new Date().toISOString().split('T')[0] : c.clearedAt,
              };
            }
            return c;
          });
          return { ...loan, conditions: updatedConditions };
        }
        return loan;
      })
    );
  };

  const updateTridFee = (loanId: string, feeId: string, leAmount: number, cdAmount: number) => {
    setLoans(prev =>
      prev.map(loan => {
        if (loan.id === loanId) {
          const updatedFees = loan.tridFees.map(fee => {
            if (fee.id === feeId) {
              return {
                ...fee,
                loanEstimateAmount: leAmount,
                closingDisclosureAmount: cdAmount,
              };
            }
            return fee;
          });
          return { ...loan, tridFees: updatedFees };
        }
        return loan;
      })
    );
  };

  const issueClearToClose = (loanId: string) => {
    advanceStage(loanId, 'clear_to_close');
    addLoanNote(loanId, 'Clear to Close (CTC) issued by Underwriting Desk. Closing docs authorized for settlement.');
  };

  const fundAndTransferToServicing = (loanId: string) => {
    const loan = loans.find(l => l.id === loanId);
    if (!loan) return;

    const monthlyPI = calculateMonthlyPI(loan.terms.loanAmount, loan.terms.interestRate, loan.terms.termMonths);
    const monthlyEscrow = Math.round((loan.property.annualPropertyTax + loan.property.annualHazardInsurance) / 12);
    const totalPITI = monthlyPI + monthlyEscrow;

    const servicingRecord = {
      servicingLoanNumber: `SRV-${Math.floor(100000 + Math.random() * 900000)}`,
      mersMin: `1008209${Math.floor(1000000000 + Math.random() * 9000000000)}`,
      currentPrincipalBalance: loan.terms.loanAmount,
      originalBalance: loan.terms.loanAmount,
      interestRate: loan.terms.interestRate,
      monthlyPaymentPITI: totalPITI,
      currentEscrowBalance: monthlyEscrow * 2, // 2 month initial cushion
      nextPaymentDueDate: '2026-11-01',
      delinquencyStatus: 'Current' as const,
      daysPastDue: 0,
      lastPaymentDate: 'None (First payment due 2026-11-01)',
      escrowCushionTargetMonths: 2,
      projectedAnnualDisbursements: [
        {
          category: 'County Property Taxes' as const,
          dueDate: '2026-12-15',
          amount: Math.round(loan.property.annualPropertyTax / 2),
        },
        {
          category: 'Hazard Homeowners Insurance' as const,
          dueDate: '2027-09-15',
          amount: loan.property.annualHazardInsurance,
        },
      ],
      paymentHistory: [],
    };

    updateLoan(loanId, {
      stage: 'servicing',
      servicing: servicingRecord,
    });
    addLoanNote(loanId, `Loan funded and onboarded into active servicing portfolio under Account #${servicingRecord.servicingLoanNumber}. MERS MIN registered.`);
  };

  const recordServicingPayment = (loanId: string, amount: number, extraPrincipal: number = 0) => {
    setLoans(prev =>
      prev.map(loan => {
        if (loan.id === loanId && loan.servicing) {
          const srv = loan.servicing;
          const monthlyRate = srv.interestRate / 100 / 12;
          const interestCharge = Math.round((srv.currentPrincipalBalance * monthlyRate) * 100) / 100;
          
          const scheduledPI = calculateMonthlyPI(srv.originalBalance, srv.interestRate, 360);
          const basePrincipal = Math.max(0, scheduledPI - interestCharge);
          const actualPrincipalPaid = Math.round((basePrincipal + extraPrincipal) * 100) / 100;

          const escrowPortion = Math.max(0, Math.round((amount - interestCharge - actualPrincipalPaid) * 100) / 100);

          const newBalance = Math.max(0, Math.round((srv.currentPrincipalBalance - actualPrincipalPaid) * 100) / 100);
          const newEscrow = Math.round((srv.currentEscrowBalance + escrowPortion) * 100) / 100;

          const todayStr = new Date().toISOString().split('T')[0];

          const paymentEntry: ServicingPaymentRecord = {
            id: `PMT-${Date.now().toString().slice(-4)}`,
            paymentDate: todayStr,
            totalReceived: amount,
            principalPortion: actualPrincipalPaid,
            interestPortion: interestCharge,
            escrowPortion: escrowPortion,
            lateFeePortion: 0,
            principalBalanceAfter: newBalance,
            escrowBalanceAfter: newEscrow,
            status: 'Completed',
          };

          return {
            ...loan,
            servicing: {
              ...srv,
              currentPrincipalBalance: newBalance,
              currentEscrowBalance: newEscrow,
              lastPaymentDate: todayStr,
              delinquencyStatus: 'Current',
              daysPastDue: 0,
              paymentHistory: [paymentEntry, ...srv.paymentHistory],
            },
          };
        }
        return loan;
      })
    );
  };

  const addLoanNote = (loanId: string, content: string) => {
    const newNote = {
      id: `NOTE-${Date.now().toString().slice(-4)}`,
      author: currentRole === 'lender' ? 'Lender Operations' : 'Wholesale Broker',
      role: currentRole === 'lender' ? 'Lender' : 'Broker',
      content,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
    };

    setLoans(prev =>
      prev.map(loan => {
        if (loan.id === loanId) {
          return {
            ...loan,
            notes: [newNote, ...loan.notes],
          };
        }
        return loan;
      })
    );
  };

  return (
    <MortgageContext.Provider
      value={{
        loans,
        selectedLoanId,
        selectedLoan,
        setSelectedLoanId,
        currentRole,
        setCurrentRole,
        currentTab,
        setCurrentTab,
        createLoan,
        updateLoan,
        advanceStage,
        runAUS,
        addCondition,
        updateConditionStatus,
        updateTridFee,
        issueClearToClose,
        fundAndTransferToServicing,
        recordServicingPayment,
        addLoanNote,
      }}
    >
      {children}
    </MortgageContext.Provider>
  );
};

export const useMortgage = () => {
  const context = useContext(MortgageContext);
  if (!context) {
    throw new Error('useMortgage must be used within a MortgageProvider');
  }
  return context;
};
