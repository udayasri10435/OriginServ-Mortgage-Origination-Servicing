import React from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { formatCurrency, formatPercent } from '../../utils/mortgageMath';
import { ChevronDown, ArrowRight } from 'lucide-react';

interface LoanSelectorBarProps {
  filterType?: 'origination' | 'servicing' | 'all';
}

export const LoanSelectorBar: React.FC<LoanSelectorBarProps> = ({ filterType = 'all' }) => {
  const { loans, selectedLoanId, setSelectedLoanId, selectedLoan } = useMortgage();

  const filteredLoans = loans.filter(l => {
    if (filterType === 'origination') return l.stage !== 'servicing';
    if (filterType === 'servicing') return l.stage === 'servicing';
    return true;
  });

  return (
    <div className="border-b border-slate-800/80 bg-slate-900/60 px-4 sm:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <label htmlFor="active-loan-select" className="text-slate-400 font-medium">Active File:</label>
          <div className="relative">
            <select
              id="active-loan-select"
              value={selectedLoanId || ''}
              onChange={(e) => setSelectedLoanId(e.target.value)}
              className="appearance-none bg-slate-950 border border-slate-700 rounded px-3 py-1.5 pr-8 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
            >
              {filteredLoans.map(loan => (
                <option key={loan.id} value={loan.id}>
                  {loan.id} · {loan.borrower.fullName} ({loan.stage.replace(/_/g, ' ')})
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {selectedLoan && (
            <div className="hidden lg:flex items-center gap-2 text-slate-400">
              <span className="font-mono text-white tabular-nums">
                {formatCurrency(selectedLoan.terms.loanAmount)}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-white tabular-nums">
                {formatPercent(selectedLoan.terms.interestRate)}
              </span>
              <span aria-hidden="true">·</span>
              <span>{selectedLoan.terms.loanType}</span>
              <span aria-hidden="true">·</span>
              <span>FICO {selectedLoan.borrower.ficoScore}</span>
            </div>
          )}
        </div>

        {selectedLoan && (
          <div className="flex items-center gap-2 text-slate-400">
            <span>Broker: <span className="text-slate-200">{selectedLoan.brokerCompany}</span></span>
            <span aria-hidden="true">·</span>
            <span>Current Stage: <span className="text-emerald-400 font-medium capitalize">{selectedLoan.stage.replace(/_/g, ' ')}</span></span>
          </div>
        )}
      </div>
    </div>
  );
};
