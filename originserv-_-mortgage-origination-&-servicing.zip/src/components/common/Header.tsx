import React from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { Building2, UserCheck, Plus, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  onOpenNewLoanModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenNewLoanModal }) => {
  const { currentRole, setCurrentRole, currentTab, setCurrentTab } = useMortgage();

  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentTab('pipeline')}
            className="flex items-center gap-2 text-left group"
          >
            <div className="w-8 h-8 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500/20 transition-colors">
              <Building2 className="w-4 h-4" />
            </div>
            <span className="text-lg font-bold tracking-tight text-white group-hover:text-emerald-400 transition-colors">
              OriginServ
            </span>
          </button>
        </div>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => setCurrentTab('pipeline')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'pipeline'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Pipeline
          </button>
          <button
            onClick={() => setCurrentTab('underwriting')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'underwriting'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Underwriting
          </button>
          <button
            onClick={() => setCurrentTab('closing')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'closing'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Closing & TRID
          </button>
          <button
            onClick={() => setCurrentTab('servicing')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'servicing'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Servicing Ledger
          </button>
          <button
            onClick={() => setCurrentTab('compliance')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'compliance'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Compliance & HMDA
          </button>
          <button
            onClick={() => setCurrentTab('pricing')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'pricing'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Broker Desk
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          {/* Role Switcher Pill-less Segmented Control */}
          <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded-md text-xs">
            <button
              onClick={() => setCurrentRole('lender')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors ${
                currentRole === 'lender'
                  ? 'bg-slate-800 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Lender View: Underwriting, Funding, Portfolio Servicing & Audit"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Lender</span>
            </button>
            <button
              onClick={() => setCurrentRole('broker')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors ${
                currentRole === 'broker'
                  ? 'bg-slate-800 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Broker View: Origination Intake, Pricing Engine & Commission Tracking"
            >
              <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Broker</span>
            </button>
          </div>

          {/* New 1003 Application CTA */}
          <button
            onClick={onOpenNewLoanModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 rounded-md hover:bg-emerald-300 transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New 1003 App</span>
          </button>
        </div>
      </div>
    </header>
  );
};
