import React, { useState } from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { calculateMonthlyPI, calculateLTV, formatCurrency, formatPercent } from '../../utils/mortgageMath';
import {
  Percent,
  Sliders,
  Lock,
  CheckCircle2,
  DollarSign,
  TrendingUp,
  ShieldCheck,
  FileCheck,
} from 'lucide-react';

export const BrokerPricingDesk: React.FC = () => {
  const { selectedLoan, updateLoan, addLoanNote } = useMortgage();

  // Pricing inputs
  const [purchasePrice, setPurchasePrice] = useState<number>(selectedLoan?.property.purchasePrice || 600000);
  const [downPayment, setDownPayment] = useState<number>(selectedLoan?.terms.downPayment || 120000);
  const [fico, setFico] = useState<number>(selectedLoan?.borrower.ficoScore || 740);
  const [loanProgram, setLoanProgram] = useState<'Conventional' | 'FHA' | 'VA' | 'Jumbo'>('Conventional');
  const [term, setTerm] = useState<number>(360);
  const [lockPeriod, setLockPeriod] = useState<number>(30);

  // Broker compensation
  const [compModel, setCompModel] = useState<'LPC' | 'BPC'>('LPC'); // Lender-Paid vs Borrower-Paid
  const [compPercent, setCompPercent] = useState<number>(1.75); // 1.75%

  const [lockedNotice, setLockedNotice] = useState<string | null>(null);

  const loanAmount = Math.max(0, purchasePrice - downPayment);
  const ltv = calculateLTV(loanAmount, purchasePrice);

  // Dynamic pricing matrix based on FICO and LTV
  const baseRate = loanProgram === 'FHA' ? 6.125 : loanProgram === 'VA' ? 6.000 : loanProgram === 'Jumbo' ? 6.750 : 6.500;
  let llpaAdjustment = 0; // Loan-Level Price Adjustment
  if (fico < 680) llpaAdjustment += 0.375;
  else if (fico < 720) llpaAdjustment += 0.125;
  if (ltv > 80) llpaAdjustment += 0.125;

  const currentParRate = baseRate + llpaAdjustment;

  // Rate sheet scenarios
  const rateScenarios = [
    { rate: currentParRate - 0.50, points: 1.750, label: 'Deep Discount Rate' },
    { rate: currentParRate - 0.25, points: 0.875, label: 'Discount Points' },
    { rate: currentParRate, points: 0.000, label: 'Par Rate (Zero Points)' },
    { rate: currentParRate + 0.25, points: -0.750, label: 'Lender Credit Rebate' },
    { rate: currentParRate + 0.50, points: -1.500, label: 'High Rebate Credit' },
  ];

  const brokerCommissionDollars = Math.round(loanAmount * (compPercent / 100));

  const handleApplyLock = (rate: number, points: number) => {
    if (selectedLoan) {
      updateLoan(selectedLoan.id, {
        terms: {
          ...selectedLoan.terms,
          interestRate: rate,
          originationPoints: points,
          isLocked: true,
          rateLockExpiry: '2026-10-31',
        },
      });
      addLoanNote(selectedLoan.id, `Rate Lock executed by Broker: ${rate.toFixed(3)}% for ${lockPeriod} days. Points/Rebate: ${points.toFixed(3)}%.`);
      setLockedNotice(`Locked ${rate.toFixed(3)}% (${lockPeriod}-day lock) on File #${selectedLoan.id}! Lock confirmation generated.`);
    } else {
      setLockedNotice(`Scenario rate ${rate.toFixed(3)}% recorded with ${lockPeriod}-day lock.`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Percent className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white tracking-tight">
              Wholesale Pricing Engine & Rate Lock Desk
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Secondary market rate sheet pricing, LLPA adjustments, and Dodd-Frank broker compensation.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">Lock Window:</span>
          <select
            value={lockPeriod}
            onChange={(e) => setLockPeriod(Number(e.target.value))}
            className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-white font-mono focus:outline-none focus:border-emerald-500"
          >
            <option value={15}>15-Day Lock</option>
            <option value={30}>30-Day Lock</option>
            <option value={45}>45-Day Lock</option>
            <option value={60}>60-Day Lock</option>
          </select>
        </div>
      </div>

      {lockedNotice && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{lockedNotice}</span>
          </div>
          <button
            onClick={() => setLockedNotice(null)}
            className="text-slate-400 hover:text-white text-xs"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Grid: Left = Scenario Filters; Right = Rate Matrix & Broker Compensation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scenario Controls (1 Col) */}
        <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white">Pricing Scenario Parameters</h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Purchase / Value ($)</label>
              <input
                type="number"
                min="0"
                step="5000"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Down Payment ($)</label>
              <input
                type="number"
                min="0"
                step="5000"
                value={downPayment}
                onChange={(e) => setDownPayment(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 font-mono text-[11px] p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div>
                <span className="text-slate-400 block">Loan Amount:</span>
                <span className="text-white font-semibold">{formatCurrency(loanAmount)}</span>
              </div>
              <div>
                <span className="text-slate-400 block">LTV Ratio:</span>
                <span className={`font-semibold ${ltv > 80 ? 'text-amber-400' : 'text-emerald-400'}`}>{ltv.toFixed(1)}%</span>
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Borrower FICO Score</label>
              <input
                type="number"
                min="580"
                max="850"
                value={fico}
                onChange={(e) => setFico(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Loan Program</label>
              <select
                value={loanProgram}
                onChange={(e) => setLoanProgram(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="Conventional">Conventional Conforming</option>
                <option value="FHA">FHA Government</option>
                <option value="VA">VA Military</option>
                <option value="Jumbo">Jumbo Non-Conforming</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Amortization Term</label>
              <select
                value={term}
                onChange={(e) => setTerm(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
              >
                <option value={360}>30-Year Fixed (360 mo)</option>
                <option value={180}>15-Year Fixed (180 mo)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Pricing Matrix & Lock Actions (2 Cols) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Rate Matrix Table */}
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">Live Rate & Price Matrix</h3>
              <span className="text-xs text-slate-400 font-mono">Live Secondary Feed</span>
            </div>

            <div className="border border-slate-800 rounded overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950 text-slate-400 font-medium">
                    <th className="py-2.5 px-4">Interest Rate</th>
                    <th className="py-2.5 px-4 text-right">Points / Rebate</th>
                    <th className="py-2.5 px-4 text-right">Points Cost ($)</th>
                    <th className="py-2.5 px-4 text-right">Monthly P&I</th>
                    <th className="py-2.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {rateScenarios.map((sc, idx) => {
                    const pointsDollars = Math.round(loanAmount * (sc.points / 100));
                    const pi = calculateMonthlyPI(loanAmount, sc.rate, term);

                    return (
                      <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-2.5 px-4 font-bold text-white">
                          {formatPercent(sc.rate)}
                          <span className="block font-sans font-normal text-[10px] text-slate-400">{sc.label}</span>
                        </td>

                        <td className="py-2.5 px-4 text-right font-medium">
                          {sc.points > 0 ? (
                            <span className="text-rose-400">+{sc.points.toFixed(3)} pts</span>
                          ) : sc.points < 0 ? (
                            <span className="text-emerald-400">{sc.points.toFixed(3)} credit</span>
                          ) : (
                            <span className="text-slate-300">0.000 (Par)</span>
                          )}
                        </td>

                        <td className="py-2.5 px-4 text-right text-slate-300">
                          {pointsDollars > 0 ? (
                            <span className="text-rose-400">+{formatCurrency(pointsDollars)}</span>
                          ) : pointsDollars < 0 ? (
                            <span className="text-emerald-400">-{formatCurrency(Math.abs(pointsDollars))}</span>
                          ) : (
                            <span>$0</span>
                          )}
                        </td>

                        <td className="py-2.5 px-4 text-right text-white font-medium">
                          {formatCurrency(pi)}/mo
                        </td>

                        <td className="py-2.5 px-4 text-right">
                          <button
                            onClick={() => handleApplyLock(sc.rate, sc.points)}
                            className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-[11px] rounded transition-colors inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Lock className="w-3 h-3" />
                            <span>Lock Rate</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Broker Compensation Model & Dodd-Frank Anti-Steering */}
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">Broker Compensation Agreement</h3>
              </div>
              <span className="text-xs text-slate-400">CFPB Anti-Steering Rule 12 CFR § 1026.36</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Compensation Structure</label>
                <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded">
                  <button
                    onClick={() => setCompModel('LPC')}
                    className={`flex-1 py-1 rounded text-center transition-colors ${
                      compModel === 'LPC' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Lender-Paid (LPC)
                  </button>
                  <button
                    onClick={() => setCompModel('BPC')}
                    className={`flex-1 py-1 rounded text-center transition-colors ${
                      compModel === 'BPC' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Borrower-Paid (BPC)
                  </button>
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Commission Rate (% of Loan)</label>
                <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-1">
                  <input
                    type="number"
                    step="0.125"
                    min="0.5"
                    max="2.75"
                    value={compPercent}
                    onChange={(e) => setCompPercent(Number(e.target.value))}
                    className="w-full bg-transparent text-white font-mono text-xs focus:outline-none"
                  />
                  <span className="text-slate-500 font-mono">%</span>
                </div>
              </div>

              <div className="p-2.5 bg-slate-950 border border-slate-800 rounded flex flex-col justify-center">
                <div className="text-[11px] text-slate-400">Estimated Broker Commission:</div>
                <div className="font-mono text-base font-bold text-emerald-400 tabular-nums">
                  {formatCurrency(brokerCommissionDollars)}
                </div>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed border-t border-slate-800 pt-3">
              Broker compensation cannot vary based on the terms or conditions of the loan transaction. Dual compensation (receiving both borrower-paid fee and lender-paid rebate on the same file) is strictly prohibited.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
