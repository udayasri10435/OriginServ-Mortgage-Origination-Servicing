import React, { useState } from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { LoanStage, LoanType } from '../../types/mortgage';
import { formatCurrency, formatPercent } from '../../utils/mortgageMath';
import { Search, SlidersHorizontal, ArrowRight, CheckCircle2, Clock, FileText, ArrowUpRight } from 'lucide-react';

interface PipelineViewProps {
  onOpenNewLoanModal: () => void;
}

export const PipelineView: React.FC<PipelineViewProps> = ({ onOpenNewLoanModal }) => {
  const { loans, setSelectedLoanId, setCurrentTab, advanceStage, currentRole } = useMortgage();
  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Metrics
  const originationLoans = loans.filter(l => l.stage !== 'servicing');
  const servicingLoans = loans.filter(l => l.stage === 'servicing');

  const totalOriginationVolume = originationLoans.reduce((sum, l) => sum + l.terms.loanAmount, 0);
  const totalServicingUPB = servicingLoans.reduce((sum, l) => sum + (l.servicing?.currentPrincipalBalance || 0), 0);
  const uwQueueCount = loans.filter(l => l.stage === 'underwriting' || l.stage === 'conditional_approval').length;
  const ctcCount = loans.filter(l => l.stage === 'clear_to_close').length;

  const filteredLoans = loans.filter(loan => {
    if (stageFilter !== 'all' && loan.stage !== stageFilter) return false;
    if (typeFilter !== 'all' && loan.terms.loanType !== typeFilter) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchName = loan.borrower.fullName.toLowerCase().includes(q);
      const matchId = loan.id.toLowerCase().includes(q);
      const matchProp = loan.property.streetAddress.toLowerCase().includes(q) || loan.property.city.toLowerCase().includes(q);
      const matchBroker = loan.brokerCompany.toLowerCase().includes(q);
      return matchName || matchId || matchProp || matchBroker;
    }
    return true;
  });

  const handleSelectLoan = (id: string, tab: string) => {
    setSelectedLoanId(id);
    setCurrentTab(tab);
  };

  const getStageLabel = (stage: LoanStage) => {
    switch (stage) {
      case 'lead': return 'Lead';
      case 'application': return 'Application Received';
      case 'processing': return 'In Processing';
      case 'underwriting': return 'Underwriting Queue';
      case 'conditional_approval': return 'Conditional Approval';
      case 'clear_to_close': return 'Clear to Close';
      case 'closing': return 'Docs Out / Closing';
      case 'funded': return 'Funded & Settled';
      case 'servicing': return 'Active Servicing';
      default: return stage;
    }
  };

  return (
    <div className="space-y-6">
      {/* KPI Stat Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Pipeline Origination Volume</div>
          <div className="mt-1 text-2xl font-bold font-mono text-white tabular-nums">
            {formatCurrency(totalOriginationVolume)}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>{originationLoans.length} active files</span>
            <span aria-hidden="true" className="mx-1.5">·</span>
            <span>Avg ${originationLoans.length ? Math.round(totalOriginationVolume / originationLoans.length / 1000) : 0}k</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Active Servicing Portfolio (UPB)</div>
          <div className="mt-1 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            {formatCurrency(totalServicingUPB)}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>{servicingLoans.length} serviced loans</span>
            <span aria-hidden="true" className="mx-1.5">·</span>
            <span>MSR Portfolio</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Underwriting & Decision Desk</div>
          <div className="mt-1 text-2xl font-bold font-mono text-cyan-400 tabular-nums">
            {uwQueueCount} <span className="text-sm font-sans font-normal text-slate-400">files</span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>DU / LPA integrated</span>
            <span aria-hidden="true" className="mx-1.5">·</span>
            <span>48h SLA</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Clear to Close (CTC) / Closing</div>
          <div className="mt-1 text-2xl font-bold font-mono text-amber-400 tabular-nums">
            {ctcCount} <span className="text-sm font-sans font-normal text-slate-400">ready</span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>TRID 3-day clock running</span>
            <span aria-hidden="true" className="mx-1.5">·</span>
            <span>Funding queue ready</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 p-3 bg-slate-900/50 border border-slate-800 rounded-lg">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search borrower, loan #, address, broker..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Stage Filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Stage:</span>
            <select
              value={stageFilter}
              onChange={(e) => setStageFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-white focus:outline-none focus:border-emerald-500"
            >
              <option value="all">All Pipeline Stages</option>
              <option value="application">Application</option>
              <option value="processing">Processing</option>
              <option value="underwriting">Underwriting</option>
              <option value="conditional_approval">Conditional Approval</option>
              <option value="clear_to_close">Clear to Close</option>
              <option value="servicing">Active Servicing</option>
            </select>
          </div>

          {/* Loan Type Filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Product:</span>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-white focus:outline-none focus:border-emerald-500"
            >
              <option value="all">All Products</option>
              <option value="Conventional">Conventional</option>
              <option value="FHA">FHA</option>
              <option value="VA">VA</option>
              <option value="Jumbo">Jumbo</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main High-Density Data Grid */}
      <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-900/30">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-medium">
                <th className="py-3 px-4">Loan File</th>
                <th className="py-3 px-4">Borrower & Credit</th>
                <th className="py-3 px-4">Subject Property</th>
                <th className="py-3 px-4 text-right">Loan Amount</th>
                <th className="py-3 px-4">Product / Rate</th>
                <th className="py-3 px-4">Current Stage</th>
                <th className="py-3 px-4">Conditions</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLoans.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    No loan applications match your search filters.
                  </td>
                </tr>
              ) : (
                filteredLoans.map((loan) => {
                  const pendingConditions = loan.conditions.filter(c => c.status !== 'cleared' && c.status !== 'waived').length;
                  const totalConditions = loan.conditions.length;
                  const isServicing = loan.stage === 'servicing';

                  return (
                    <tr
                      key={loan.id}
                      className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                      onClick={() => handleSelectLoan(loan.id, isServicing ? 'servicing' : 'underwriting')}
                    >
                      <td className="py-3 px-4">
                        <div className="font-mono font-medium text-white">{loan.id}</div>
                        <div className="text-[11px] text-slate-500 truncate max-w-[160px]">{loan.brokerCompany}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-200">{loan.borrower.fullName}</div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                          <span>FICO <span className="font-mono text-emerald-400">{loan.borrower.ficoScore}</span></span>
                          <span aria-hidden="true">·</span>
                          <span className="truncate max-w-[120px]">{loan.borrower.jobTitle}</span>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="text-slate-200 truncate max-w-[180px]">{loan.property.streetAddress}</div>
                        <div className="text-[11px] text-slate-500">
                          {loan.property.city}, {loan.property.state} · {loan.property.occupancy.replace(' Residence', '')}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-medium text-white tabular-nums">
                        {isServicing && loan.servicing
                          ? formatCurrency(loan.servicing.currentPrincipalBalance)
                          : formatCurrency(loan.terms.loanAmount)}
                      </td>

                      <td className="py-3 px-4">
                        <div className="text-slate-200">{loan.terms.loanType} {loan.terms.termMonths / 12}Y</div>
                        <div className="text-[11px] font-mono text-slate-400 tabular-nums">
                          {formatPercent(loan.terms.interestRate)} · APR {formatPercent(loan.terms.apr)}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="text-slate-200 font-medium">{getStageLabel(loan.stage)}</div>
                        <div className="text-[11px] text-slate-500">
                          Updated {loan.updatedAt}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        {isServicing ? (
                          <div className="text-slate-400 text-[11px]">
                            {loan.servicing?.delinquencyStatus}
                          </div>
                        ) : totalConditions > 0 ? (
                          <div className="text-[11px] text-slate-400">
                            <span className={pendingConditions > 0 ? 'text-amber-400 font-mono' : 'text-emerald-400 font-mono'}>
                              {totalConditions - pendingConditions} of {totalConditions}
                            </span> cleared
                          </div>
                        ) : (
                          <span className="text-slate-500 text-[11px]">No conditions</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          {isServicing ? (
                            <button
                              onClick={() => handleSelectLoan(loan.id, 'servicing')}
                              className="px-2.5 py-1 text-[11px] font-medium text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 rounded transition-colors"
                            >
                              Ledger
                            </button>
                          ) : (
                            <>
                              <button
                                onClick={() => handleSelectLoan(loan.id, 'underwriting')}
                                className="px-2 py-1 text-[11px] font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                                title="View Underwriting Desk"
                              >
                                Underwrite
                              </button>
                              <button
                                onClick={() => handleSelectLoan(loan.id, 'closing')}
                                className="px-2 py-1 text-[11px] font-medium text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 rounded transition-colors"
                                title="View TRID Closing Disclosures"
                              >
                                Closing
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
