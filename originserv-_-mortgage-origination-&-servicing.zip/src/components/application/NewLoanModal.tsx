import React, { useState, useMemo } from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { LoanApplication, LoanType, LoanPurpose, PropertyType, OccupancyType } from '../../types/mortgage';
import {
  calculateMonthlyPI,
  calculateMonthlyPMI,
  calculateFrontEndDTI,
  calculateBackEndDTI,
  calculateLTV,
  formatCurrency,
  formatPercent,
} from '../../utils/mortgageMath';
import { X, Check, Calculator, Building, ShieldCheck, DollarSign } from 'lucide-react';

interface NewLoanModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewLoanModal: React.FC<NewLoanModalProps> = ({ isOpen, onClose }) => {
  const { createLoan, currentRole } = useMortgage();

  // Form State
  const [borrowerName, setBorrowerName] = useState('David & Emma Wilson');
  const [email, setEmail] = useState('emma.wilson@example.com');
  const [phone, setPhone] = useState('(503) 891-2099');
  const [ssnMasked, setSsnMasked] = useState('***-**-6410');
  const [ficoScore, setFicoScore] = useState(745);
  const [employer, setEmployer] = useState('Intel Corporation');
  const [jobTitle, setJobTitle] = useState('Senior Systems Architect');
  const [yearsEmployed, setYearsEmployed] = useState(4.2);
  const [monthlyBaseIncome, setMonthlyBaseIncome] = useState(14500);
  const [monthlyOtherIncome, setMonthlyOtherIncome] = useState(1200);

  // Debts
  const [autoLoanPayment, setAutoLoanPayment] = useState(450);
  const [creditCardPayment, setCreditCardPayment] = useState(180);
  const [studentLoanPayment, setStudentLoanPayment] = useState(250);

  // Property
  const [streetAddress, setStreetAddress] = useState('1492 NW Skyline Blvd');
  const [city, setCity] = useState('Portland');
  const [state, setState] = useState('OR');
  const [zipCode, setZipCode] = useState('97229');
  const [propertyType, setPropertyType] = useState<PropertyType>('Single Family');
  const [occupancy, setOccupancy] = useState<OccupancyType>('Primary Residence');
  const [purchasePrice, setPurchasePrice] = useState(580000);
  const [downPayment, setDownPayment] = useState(116000); // 20% down
  const [annualPropertyTax, setAnnualPropertyTax] = useState(6960);
  const [annualHazardInsurance, setAnnualHazardInsurance] = useState(1440);
  const [monthlyHOA, setMonthlyHOA] = useState(0);

  // Terms
  const [loanType, setLoanType] = useState<LoanType>('Conventional');
  const [loanPurpose, setLoanPurpose] = useState<LoanPurpose>('Purchase');
  const [termMonths, setTermMonths] = useState(360);
  const [interestRate, setInterestRate] = useState(6.500);

  // Calculations
  const loanAmount = Math.max(0, purchasePrice - downPayment);
  const ltv = calculateLTV(loanAmount, purchasePrice);
  const monthlyPI = calculateMonthlyPI(loanAmount, interestRate, termMonths);
  const monthlyTax = annualPropertyTax / 12;
  const monthlyIns = annualHazardInsurance / 12;
  const monthlyPMI = calculateMonthlyPMI(loanAmount, purchasePrice, ficoScore);
  const totalMonthlyHousing = monthlyPI + monthlyTax + monthlyIns + monthlyHOA + monthlyPMI;

  const totalMonthlyIncome = monthlyBaseIncome + monthlyOtherIncome;
  const totalMonthlyDebts = autoLoanPayment + creditCardPayment + studentLoanPayment;

  const frontDTI = calculateFrontEndDTI(totalMonthlyHousing, totalMonthlyIncome);
  const backDTI = calculateBackEndDTI(totalMonthlyHousing, totalMonthlyDebts, totalMonthlyIncome);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newId = `LN-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newLoan: LoanApplication = {
      id: newId,
      stage: 'underwriting',
      brokerCompany: currentRole === 'broker' ? 'Apex Mortgage Partners' : 'Keystone Wholesale Mortgage LLC',
      loanOfficerName: currentRole === 'broker' ? 'Direct Broker Submission' : 'In-House Lending Desk',
      borrower: {
        fullName: borrowerName,
        email,
        phone,
        ssnMasked,
        ficoScore: Number(ficoScore),
        employer,
        jobTitle,
        yearsEmployed: Number(yearsEmployed),
        monthlyBaseIncome: Number(monthlyBaseIncome),
        monthlyOtherIncome: Number(monthlyOtherIncome),
        monthlyDebts: [
          { name: 'Auto Loan', type: 'Auto', monthlyPayment: Number(autoLoanPayment), balance: autoLoanPayment * 24 },
          { name: 'Revolving Cards', type: 'Credit Card', monthlyPayment: Number(creditCardPayment), balance: creditCardPayment * 12 },
          { name: 'Student Loans', type: 'Student Loan', monthlyPayment: Number(studentLoanPayment), balance: studentLoanPayment * 48 },
        ],
        liquidAssets: [
          { institution: 'First National Bank', type: 'Checking', amount: 45000 },
          { institution: 'Fidelity Investments', type: 'Brokerage', amount: 120000 },
        ],
      },
      property: {
        streetAddress,
        city,
        state,
        zipCode,
        propertyType,
        occupancy,
        purchasePrice: Number(purchasePrice),
        appraisedValue: Number(purchasePrice),
        annualPropertyTax: Number(annualPropertyTax),
        annualHazardInsurance: Number(annualHazardInsurance),
        monthlyHOA: Number(monthlyHOA),
      },
      terms: {
        loanAmount,
        downPayment: Number(downPayment),
        termMonths: Number(termMonths),
        interestRate: Number(interestRate),
        apr: Number((interestRate + 0.185).toFixed(3)),
        loanType,
        loanPurpose,
        rateLockExpiry: '2026-10-31',
        isLocked: true,
        originationPoints: 0,
      },
      aus: {
        system: loanType === 'FHA' ? 'Desktop Underwriter (DU)' : 'Loan Product Advisor (LPA)',
        recommendation: backDTI <= 45 && ficoScore >= 660 ? 'Approve/Eligible' : 'Refer/Eligible',
        runDate: new Date().toISOString().split('T')[0],
        caseFileId: `DU-${Math.floor(1000000 + Math.random() * 9000000)}`,
        findings: [
          `Income verified at $${totalMonthlyIncome.toLocaleString()}/mo.`,
          `Back-End DTI calculated at ${backDTI}% (Threshold compliant).`,
          `LTV verified at ${ltv}% on purchase price $${purchasePrice.toLocaleString()}.`,
          'Automated underwriting accept recommendation conditioned on asset & employment sign-offs.',
        ],
      },
      conditions: [
        {
          id: 'C-NEW-1',
          category: 'PTD',
          title: '30-Day Paystubs & W-2s',
          description: `Provide most recent 30 days paystubs for ${borrowerName} reflecting YTD earnings.`,
          status: 'pending',
          requiredDocumentName: 'Paystubs_Current.pdf',
        },
        {
          id: 'C-NEW-2',
          category: 'PTD',
          title: '2-Month Bank Statements (Asset Sourcing)',
          description: 'Provide 60 days complete asset verification confirming down payment funds.',
          status: 'pending',
          requiredDocumentName: 'Bank_Statements_DownPayment.pdf',
        },
        {
          id: 'C-NEW-3',
          category: 'PTC',
          title: 'Hazard Homeowners Insurance Policy',
          description: 'Provide 12-month paid binder with lender loss payee endorsement.',
          status: 'pending',
        },
      ],
      tridFees: [
        { id: 'F-1', name: 'Origination Fee', category: 'origination', toleranceCategory: 'zero', loanEstimateAmount: 995, closingDisclosureAmount: 995, paidBy: 'Borrower' },
        { id: 'F-2', name: 'Underwriting Review Fee', category: 'origination', toleranceCategory: 'zero', loanEstimateAmount: 795, closingDisclosureAmount: 795, paidBy: 'Borrower' },
        { id: 'F-3', name: 'Credit Report Tri-Merge', category: 'services_cannot_shop', toleranceCategory: 'zero', loanEstimateAmount: 75, closingDisclosureAmount: 75, paidBy: 'Borrower' },
        { id: 'F-4', name: 'Appraisal Inspection Form 1004', category: 'services_cannot_shop', toleranceCategory: 'zero', loanEstimateAmount: 625, closingDisclosureAmount: 625, paidBy: 'Borrower' },
        { id: 'F-5', name: 'Title - Lender\'s Title Policy', category: 'services_can_shop', toleranceCategory: 'ten_percent', loanEstimateAmount: 1650, closingDisclosureAmount: 1650, paidBy: 'Borrower' },
        { id: 'F-6', name: 'Title - Settlement & Escrow Closing Fee', category: 'services_can_shop', toleranceCategory: 'ten_percent', loanEstimateAmount: 1100, closingDisclosureAmount: 1100, paidBy: 'Borrower' },
        { id: 'F-7', name: 'City / County Transfer Taxes', category: 'taxes_gov', toleranceCategory: 'zero', loanEstimateAmount: 580, closingDisclosureAmount: 580, paidBy: 'Borrower' },
        { id: 'F-8', name: 'Government Recording Fees', category: 'taxes_gov', toleranceCategory: 'ten_percent', loanEstimateAmount: 195, closingDisclosureAmount: 195, paidBy: 'Borrower' },
        { id: 'F-9', name: 'Prepaid Daily Interest (15 Days)', category: 'prepaids', toleranceCategory: 'unlimited', loanEstimateAmount: Math.round((loanAmount * (interestRate / 100) / 365) * 15), closingDisclosureAmount: Math.round((loanAmount * (interestRate / 100) / 365) * 15), paidBy: 'Borrower' },
        { id: 'F-10', name: 'Prepaid Homeowner Hazard Insurance', category: 'prepaids', toleranceCategory: 'unlimited', loanEstimateAmount: annualHazardInsurance, closingDisclosureAmount: annualHazardInsurance, paidBy: 'Borrower' },
      ],
      compliance: {
        qmStatus: 'QM Safe Harbor',
        totalPointsAndFees: 2465,
        pointsAndFeesPercentage: Number(((2465 / loanAmount) * 100).toFixed(3)),
        pointsFeesCapThreshold: 3.0,
        passesPointsAndFees: true,
        atrCompliant: true,
        hmdaActionTakenCode: 1,
        rateSpread: 0.18,
        censusTract: '410510045.01',
        demographicsProvided: true,
      },
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      notes: [
        {
          id: 'NOTE-INIT',
          author: currentRole === 'broker' ? 'Broker Desk' : 'Origination Officer',
          role: currentRole === 'broker' ? 'Broker' : 'Lender',
          content: 'Application submitted into underwriting queue. Initial AUS analysis generated.',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
        },
      ],
    };

    createLoan(newLoan);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Calculator className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Uniform Residential Loan Application (Form 1003)
              </h2>
              <div className="text-xs text-slate-400">
                <span>Direct Origination Intake</span>
                <span aria-hidden="true" className="mx-1.5">·</span>
                <span>Wholesale & Retail Lending</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Form (Left) + Live Underwriting DTI Calculator (Right) */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form Fields (2 Cols) */}
          <div className="lg:col-span-2 space-y-6">
            {/* 1. Borrower Section */}
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                <span>01. Borrower Profile & Capacity</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">Borrower Full Name(s)</label>
                  <input
                    type="text"
                    required
                    value={borrowerName}
                    onChange={(e) => setBorrowerName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Credit Score (Tri-Merge Mid FICO)</label>
                  <input
                    type="number"
                    min="500"
                    max="850"
                    required
                    value={ficoScore}
                    onChange={(e) => setFicoScore(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Primary Employer</label>
                  <input
                    type="text"
                    value={employer}
                    onChange={(e) => setEmployer(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Job Title</label>
                  <input
                    type="text"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Gross Monthly Base Income ($)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={monthlyBaseIncome}
                    onChange={(e) => setMonthlyBaseIncome(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Other Qualified Monthly Income ($)</label>
                  <input
                    type="number"
                    min="0"
                    value={monthlyOtherIncome}
                    onChange={(e) => setMonthlyOtherIncome(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* 2. Monthly Liabilities & Debts */}
            <div className="pt-2 border-t border-slate-800/80">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
                <span>02. Monthly Recurring Debts (Excluding Rent)</span>
                <span className="font-mono text-white tabular-nums">${totalMonthlyDebts}/mo total</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">Auto Installments ($/mo)</label>
                  <input
                    type="number"
                    min="0"
                    value={autoLoanPayment}
                    onChange={(e) => setAutoLoanPayment(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Credit Card Min. ($/mo)</label>
                  <input
                    type="number"
                    min="0"
                    value={creditCardPayment}
                    onChange={(e) => setCreditCardPayment(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Student Loans / Other ($/mo)</label>
                  <input
                    type="number"
                    min="0"
                    value={studentLoanPayment}
                    onChange={(e) => setStudentLoanPayment(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* 3. Subject Property */}
            <div className="pt-2 border-t border-slate-800/80">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                <span>03. Subject Property & Escrow</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="sm:col-span-2">
                  <label className="text-slate-400 block mb-1">Street Address</label>
                  <input
                    type="text"
                    required
                    value={streetAddress}
                    onChange={(e) => setStreetAddress(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">City, State Zip</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="City"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-1/2 bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                    />
                    <input
                      type="text"
                      placeholder="ST"
                      maxLength={2}
                      value={state}
                      onChange={(e) => setState(e.target.value.toUpperCase())}
                      className="w-1/4 bg-slate-950 border border-slate-800 rounded px-2 py-1.5 text-white text-center focus:outline-none focus:border-emerald-500 uppercase"
                    />
                    <input
                      type="text"
                      placeholder="Zip"
                      value={zipCode}
                      onChange={(e) => setZipCode(e.target.value)}
                      className="w-1/4 bg-slate-950 border border-slate-800 rounded px-2 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Property Type</label>
                  <select
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value as PropertyType)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Single Family">Single Family</option>
                    <option value="Condominium">Condominium</option>
                    <option value="Townhome">Townhome</option>
                    <option value="Multi-Family (2-4 Units)">Multi-Family (2-4 Units)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Occupancy</label>
                  <select
                    value={occupancy}
                    onChange={(e) => setOccupancy(e.target.value as OccupancyType)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Primary Residence">Primary Residence</option>
                    <option value="Secondary / Vacation">Secondary / Vacation</option>
                    <option value="Investment Property">Investment Property</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Purchase Price ($)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Down Payment ($)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={downPayment}
                    onChange={(e) => setDownPayment(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Annual Property Taxes ($)</label>
                  <input
                    type="number"
                    min="0"
                    value={annualPropertyTax}
                    onChange={(e) => setAnnualPropertyTax(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Annual Hazard Insurance ($)</label>
                  <input
                    type="number"
                    min="0"
                    value={annualHazardInsurance}
                    onChange={(e) => setAnnualHazardInsurance(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* 4. Financing Terms */}
            <div className="pt-2 border-t border-slate-800/80">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                <span>04. Financing Terms</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">Loan Program</label>
                  <select
                    value={loanType}
                    onChange={(e) => setLoanType(e.target.value as LoanType)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Conventional">Conventional</option>
                    <option value="FHA">FHA</option>
                    <option value="VA">VA</option>
                    <option value="Jumbo">Jumbo</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Loan Purpose</label>
                  <select
                    value={loanPurpose}
                    onChange={(e) => setLoanPurpose(e.target.value as LoanPurpose)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Purchase">Purchase</option>
                    <option value="Rate & Term Refi">Rate & Term Refi</option>
                    <option value="Cash-Out Refi">Cash-Out Refi</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Amortization Term</label>
                  <select
                    value={termMonths}
                    onChange={(e) => setTermMonths(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value={360}>30-Year Fixed (360 mo)</option>
                    <option value={180}>15-Year Fixed (180 mo)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Note Interest Rate (%)</label>
                  <input
                    type="number"
                    step="0.125"
                    min="1"
                    max="15"
                    required
                    value={interestRate}
                    onChange={(e) => setInterestRate(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Live Underwriting & Capacity Sidebar (1 Col) */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 flex flex-col justify-between space-y-4">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-3 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                <span>Live Underwriting Metrics</span>
              </div>

              {/* Loan Amount & LTV */}
              <div className="space-y-3 text-xs border-b border-slate-800/80 pb-4">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Total Loan Amount:</span>
                  <span className="font-mono font-semibold text-white tabular-nums">
                    {formatCurrency(loanAmount)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Loan-to-Value (LTV):</span>
                  <span className={`font-mono font-semibold tabular-nums ${ltv > 80 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {ltv.toFixed(1)}% {ltv > 80 && '(PMI Req)'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Down Payment %:</span>
                  <span className="font-mono text-slate-200 tabular-nums">
                    {purchasePrice > 0 ? ((downPayment / purchasePrice) * 100).toFixed(1) : 0}%
                  </span>
                </div>
              </div>

              {/* Monthly Payment PITI Breakdown */}
              <div className="py-4 border-b border-slate-800/80 space-y-2 text-xs">
                <div className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Monthly Housing (PITI) Breakdown
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Principal & Interest (P&I):</span>
                  <span className="font-mono text-slate-200 tabular-nums">{formatCurrency(monthlyPI)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Property Taxes:</span>
                  <span className="font-mono text-slate-200 tabular-nums">{formatCurrency(monthlyTax)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Hazard Insurance:</span>
                  <span className="font-mono text-slate-200 tabular-nums">{formatCurrency(monthlyIns)}</span>
                </div>
                {monthlyPMI > 0 && (
                  <div className="flex justify-between items-center text-amber-400">
                    <span>Mortgage Insurance (PMI):</span>
                    <span className="font-mono tabular-nums">+{formatCurrency(monthlyPMI)}</span>
                  </div>
                )}
                {monthlyHOA > 0 && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">HOA Dues:</span>
                    <span className="font-mono text-slate-200 tabular-nums">{formatCurrency(monthlyHOA)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-sm font-semibold text-white">
                  <span>Total PITI Payment:</span>
                  <span className="font-mono text-emerald-400 tabular-nums">{formatCurrency(totalMonthlyHousing)}/mo</span>
                </div>
              </div>

              {/* Debt-to-Income (DTI) Meters */}
              <div className="pt-4 space-y-3 text-xs">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-slate-400">Front-End DTI (Housing):</span>
                    <span className={`font-mono font-semibold tabular-nums ${frontDTI > 28 ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {frontDTI}% <span className="text-slate-500 font-normal">/ 28.0% max</span>
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${frontDTI > 28 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                      style={{ width: `${Math.min(100, (frontDTI / 45) * 100)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-slate-400">Back-End DTI (Total Debt):</span>
                    <span className={`font-mono font-semibold tabular-nums ${backDTI > 43 ? (backDTI > 50 ? 'text-rose-400' : 'text-amber-400') : 'text-emerald-400'}`}>
                      {backDTI}% <span className="text-slate-500 font-normal">/ 43.0% QM</span>
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${backDTI > 50 ? 'bg-rose-500' : backDTI > 43 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                      style={{ width: `${Math.min(100, (backDTI / 55) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-slate-800 space-y-2">
              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>Submit Application to Underwriting</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
