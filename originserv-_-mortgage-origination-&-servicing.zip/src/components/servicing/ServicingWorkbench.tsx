import React, { useState, useMemo } from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { LoanSelectorBar } from '../common/LoanSelectorBar';
import {
  generateAmortizationSchedule,
  formatCurrency,
  formatCurrencyPrecise,
  formatPercent,
} from '../../utils/mortgageMath';
import {
  Landmark,
  CreditCard,
  Calendar,
  AlertCircle,
  TrendingDown,
  Clock,
  CheckCircle2,
  DollarSign,
  ArrowRight,
  Calculator,
  RefreshCw,
} from 'lucide-react';

export const ServicingWorkbench: React.FC = () => {
  const { loans, selectedLoan, setSelectedLoanId, recordServicingPayment, addLoanNote } = useMortgage();

  const servicedLoans = loans.filter(l => l.stage === 'servicing' && l.servicing);
  const activeLoan = selectedLoan?.stage === 'servicing' && selectedLoan.servicing
    ? selectedLoan
    : servicedLoans[0];

  const srv = activeLoan?.servicing;

  // Portfolio aggregates
  const totalPortfolioUPB = servicedLoans.reduce((sum, l) => sum + (l.servicing?.currentPrincipalBalance || 0), 0);
  const totalEscrowCustody = servicedLoans.reduce((sum, l) => sum + (l.servicing?.currentEscrowBalance || 0), 0);
  const delinquentLoans = servicedLoans.filter(l => l.servicing?.delinquencyStatus !== 'Current');
  const weightedRateSum = servicedLoans.reduce((sum, l) => sum + (l.servicing ? l.servicing.currentPrincipalBalance * l.servicing.interestRate : 0), 0);
  const wac = totalPortfolioUPB > 0 ? (weightedRateSum / totalPortfolioUPB) : 0;

  // Payment form state
  const [paymentAmount, setPaymentAmount] = useState<number>(srv ? srv.monthlyPaymentPITI : 2500);
  const [extraPrincipal, setExtraPrincipal] = useState<number>(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Amortization accelerator state
  const [acceleratorExtraPrincipal, setAcceleratorExtraPrincipal] = useState<number>(150);
  const [activeTab, setActiveTab] = useState<'terminal' | 'amortization' | 'escrow'>('terminal');

  // Sync payment input when activeLoan changes
  React.useEffect(() => {
    if (srv) {
      setPaymentAmount(srv.monthlyPaymentPITI);
      setExtraPrincipal(0);
      setSuccessNotice(null);
    }
  }, [activeLoan?.id]);

  // Amortization calculation
  const amortBase = useMemo(() => {
    if (!srv) return [];
    return generateAmortizationSchedule(srv.originalBalance, srv.interestRate, 360, 0);
  }, [srv?.originalBalance, srv?.interestRate]);

  const amortAccelerated = useMemo(() => {
    if (!srv) return [];
    return generateAmortizationSchedule(srv.currentPrincipalBalance, srv.interestRate, 360, acceleratorExtraPrincipal);
  }, [srv?.currentPrincipalBalance, srv?.interestRate, acceleratorExtraPrincipal]);

  const totalInterestOriginal = amortBase.reduce((sum, r) => sum + r.interest, 0);
  const totalInterestAccelerated = amortAccelerated.reduce((sum, r) => sum + r.interest, 0);
  const interestSaved = Math.max(0, Math.round(totalInterestOriginal - totalInterestAccelerated));
  const payoffMonthsSaved = Math.max(0, amortBase.length - amortAccelerated.length);

  // Escrow analysis
  const annualDisbursements = srv?.projectedAnnualDisbursements.reduce((sum, d) => sum + d.amount, 0) || 0;
  const monthlyEscrowNeed = annualDisbursements / 12;
  const requiredCushion = monthlyEscrowNeed * (srv?.escrowCushionTargetMonths || 2);
  const escrowSurplusOrShortage = srv ? Math.round((srv.currentEscrowBalance - requiredCushion) * 100) / 100 : 0;

  if (!activeLoan || !srv) {
    return (
      <div className="text-center py-20 text-slate-500">
        No active loans in servicing portfolio. Fund a loan from the Closing tab to onboard into servicing.
      </div>
    );
  }

  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      const totalPaid = Number(paymentAmount) + Number(extraPrincipal);
      recordServicingPayment(activeLoan.id, totalPaid, Number(extraPrincipal));
      setIsProcessing(false);
      setSuccessNotice(`Payment of ${formatCurrencyPrecise(totalPaid)} successfully applied to Account #${srv.servicingLoanNumber}. Principal balance updated.`);
      setExtraPrincipal(0);
    }, 500);
  };

  return (
    <div className="space-y-6">
      {/* Portfolio Aggregates Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Serviced Portfolio (UPB)</div>
          <div className="mt-1 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            {formatCurrency(totalPortfolioUPB)}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>{servicedLoans.length} active notes</span>
            <span aria-hidden="true" className="mx-1.5">·</span>
            <span>MSR Portfolio</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Weighted Avg Coupon (WAC)</div>
          <div className="mt-1 text-2xl font-bold font-mono text-white tabular-nums">
            {formatPercent(wac)}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>Fixed Rate Weighted Yield</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Custodial Escrow Reserves</div>
          <div className="mt-1 text-2xl font-bold font-mono text-cyan-400 tabular-nums">
            {formatCurrency(totalEscrowCustody)}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>T&I Reserves under RESPA 10</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Delinquency Status (DPD)</div>
          <div className={`mt-1 text-2xl font-bold font-mono tabular-nums ${delinquentLoans.length > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {delinquentLoans.length} <span className="text-sm font-sans font-normal text-slate-400">delinquent</span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>{((servicedLoans.length - delinquentLoans.length) / (servicedLoans.length || 1) * 100).toFixed(0)}% Current Rate</span>
          </div>
        </div>
      </div>

      {/* Account Header & File Selector */}
      <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="w-10 h-10 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Landmark className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-tight">
                {activeLoan.borrower.fullName}
              </h2>
              <span className="text-xs text-slate-400 font-mono">
                Acct #{srv.servicingLoanNumber}
              </span>
              <span className={`text-[11px] font-medium font-mono ${srv.delinquencyStatus === 'Current' ? 'text-emerald-400' : 'text-amber-400'}`}>
                [{srv.delinquencyStatus}]
              </span>
            </div>
            <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
              <span>{activeLoan.property.streetAddress}, {activeLoan.property.city}</span>
              <span aria-hidden="true">·</span>
              <span>MERS MIN: <span className="font-mono text-slate-300">{srv.mersMin}</span></span>
              <span aria-hidden="true">·</span>
              <span>Rate: <span className="font-mono text-slate-200">{formatPercent(srv.interestRate)}</span></span>
            </div>
          </div>
        </div>

        {/* Loan Switcher Dropdown */}
        <div className="flex items-center gap-2 text-xs">
          <label className="text-slate-400">Select Serviced Loan:</label>
          <select
            value={activeLoan.id}
            onChange={(e) => setSelectedLoanId(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-white text-xs font-mono focus:outline-none focus:border-emerald-500"
          >
            {servicedLoans.map(l => (
              <option key={l.id} value={l.id}>
                {l.servicing?.servicingLoanNumber} · {l.borrower.fullName} ({l.servicing?.delinquencyStatus})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Servicing Navigation Tabs: Payment Terminal | Amortization Schedule | Annual Escrow */}
      <div className="flex items-center gap-1 border-b border-slate-800 text-xs">
        <button
          onClick={() => setActiveTab('terminal')}
          className={`pb-2.5 px-3 font-medium transition-colors border-b-2 ${
            activeTab === 'terminal'
              ? 'border-emerald-400 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Payment Processing Terminal & Ledger
        </button>
        <button
          onClick={() => setActiveTab('amortization')}
          className={`pb-2.5 px-3 font-medium transition-colors border-b-2 ${
            activeTab === 'amortization'
              ? 'border-emerald-400 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Amortization & Principal Accelerator
        </button>
        <button
          onClick={() => setActiveTab('escrow')}
          className={`pb-2.5 px-3 font-medium transition-colors border-b-2 ${
            activeTab === 'escrow'
              ? 'border-emerald-400 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Annual Escrow Analysis (RESPA 10)
        </button>
      </div>

      {/* Tab 1: Payment Processing Terminal & Ledger */}
      {activeTab === 'terminal' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Payment Terminal Form (1 Col) */}
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">Payment Processing Terminal</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">ACH Direct</span>
            </div>

            {successNotice && (
              <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 text-xs flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{successNotice}</span>
              </div>
            )}

            <form onSubmit={handleProcessPayment} className="space-y-3 text-xs">
              <div className="p-2.5 bg-slate-950 border border-slate-800/80 rounded space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>Current UPB:</span>
                  <span className="text-white font-semibold">{formatCurrencyPrecise(srv.currentPrincipalBalance)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Escrow Balance:</span>
                  <span className="text-cyan-400 font-semibold">{formatCurrencyPrecise(srv.currentEscrowBalance)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Next Due Date:</span>
                  <span className="text-slate-200">{srv.nextPaymentDueDate}</span>
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Scheduled Monthly PITI Payment ($)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Extra Principal Curtailment ($)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={extraPrincipal}
                  onChange={(e) => setExtraPrincipal(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                />
                <span className="text-[11px] text-slate-500 mt-0.5 block">Applied 100% to reduce principal balance</span>
              </div>

              <div className="p-2.5 bg-slate-950 border border-slate-800/80 rounded text-[11px] space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>Estimated Interest Split:</span>
                  <span className="font-mono text-slate-300">
                    ~{formatCurrencyPrecise((srv.currentPrincipalBalance * (srv.interestRate / 100 / 12)))}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Estimated Escrow Split:</span>
                  <span className="font-mono text-slate-300">
                    ~{formatCurrencyPrecise(srv.monthlyPaymentPITI - 2333 > 0 ? srv.monthlyPaymentPITI - 2333 : 475)}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <DollarSign className="w-4 h-4" />
                <span>{isProcessing ? 'Processing ACH Transaction...' : 'Post & Process Payment'}</span>
              </button>
            </form>
          </div>

          {/* Servicing Payment Ledger History (2 Cols) */}
          <div className="lg:col-span-2 p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">Payment Transaction Ledger</h3>
                <span className="text-xs text-slate-400 font-mono">
                  {srv.paymentHistory.length} posted transactions
                </span>
              </div>

              <div className="mt-3 border border-slate-800 rounded overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950 text-slate-400 font-medium">
                      <th className="py-2 px-3">Date</th>
                      <th className="py-2 px-3 text-right">Total Paid</th>
                      <th className="py-2 px-3 text-right">Principal</th>
                      <th className="py-2 px-3 text-right">Interest</th>
                      <th className="py-2 px-3 text-right">Escrow</th>
                      <th className="py-2 px-3 text-right">Ending UPB</th>
                      <th className="py-2 px-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                    {srv.paymentHistory.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-500 font-sans">
                          No payment transactions recorded yet. Process the initial payment on the left.
                        </td>
                      </tr>
                    ) : (
                      srv.paymentHistory.map((pmt) => (
                        <tr key={pmt.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="py-2 px-3 text-slate-300">{pmt.paymentDate}</td>
                          <td className="py-2 px-3 text-right text-white font-medium">
                            {formatCurrencyPrecise(pmt.totalReceived)}
                          </td>
                          <td className="py-2 px-3 text-right text-emerald-400">
                            {formatCurrencyPrecise(pmt.principalPortion)}
                          </td>
                          <td className="py-2 px-3 text-right text-slate-300">
                            {formatCurrencyPrecise(pmt.interestPortion)}
                          </td>
                          <td className="py-2 px-3 text-right text-cyan-400">
                            {formatCurrencyPrecise(pmt.escrowPortion)}
                          </td>
                          <td className="py-2 px-3 text-right text-slate-200">
                            {formatCurrencyPrecise(pmt.principalBalanceAfter)}
                          </td>
                          <td className="py-2 px-3 text-center font-sans">
                            <span className="text-emerald-400 text-[10px]">Posted</span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="pt-2 text-xs text-slate-500 flex items-center justify-between border-t border-slate-800/80">
              <span>Custodial Account Held at J.P. Morgan Chase & Co.</span>
              <span>1098 Mortgage Interest Reporting Compliant</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Amortization & Principal Accelerator */}
      {activeTab === 'amortization' && (
        <div className="space-y-6">
          {/* Accelerator Simulation Header */}
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">Extra Principal Payment Accelerator</h3>
              </div>
              <p className="text-xs text-slate-400">
                Simulate accelerating mortgage payoff by applying additional monthly principal.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-xs">
                <label className="text-slate-400">Extra Monthly Principal:</label>
                <div className="flex items-center gap-1 bg-slate-950 border border-slate-700 rounded px-2 py-1">
                  <span className="text-slate-400 font-mono">$</span>
                  <input
                    type="number"
                    min="0"
                    step="50"
                    value={acceleratorExtraPrincipal}
                    onChange={(e) => setAcceleratorExtraPrincipal(Number(e.target.value))}
                    className="w-20 bg-transparent text-white font-mono text-xs focus:outline-none"
                  />
                  <span className="text-slate-500 font-mono">/mo</span>
                </div>
              </div>

              <div className="text-right text-xs">
                <div className="text-emerald-400 font-bold font-mono text-sm">
                  Save {formatCurrency(interestSaved)} interest
                </div>
                <div className="text-slate-400 text-[11px]">
                  Pay off {Math.floor(payoffMonthsSaved / 12)} yrs {payoffMonthsSaved % 12} mos sooner
                </div>
              </div>
            </div>
          </div>

          {/* Amortization Table */}
          <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-900/30">
            <div className="max-h-96 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="sticky top-0 bg-slate-950 border-b border-slate-800 text-slate-400 font-medium">
                  <tr>
                    <th className="py-2.5 px-4">Month #</th>
                    <th className="py-2.5 px-4 text-right">Payment</th>
                    <th className="py-2.5 px-4 text-right">Principal</th>
                    <th className="py-2.5 px-4 text-right">Interest</th>
                    <th className="py-2.5 px-4 text-right">Cumulative Interest</th>
                    <th className="py-2.5 px-4 text-right">Remaining Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {amortAccelerated.slice(0, 120).map((row) => (
                    <tr key={row.month} className="hover:bg-slate-800/30">
                      <td className="py-2 px-4 text-slate-400">Month {row.month}</td>
                      <td className="py-2 px-4 text-right text-white font-medium">{formatCurrencyPrecise(row.payment)}</td>
                      <td className="py-2 px-4 text-right text-emerald-400">{formatCurrencyPrecise(row.principal)}</td>
                      <td className="py-2 px-4 text-right text-slate-300">{formatCurrencyPrecise(row.interest)}</td>
                      <td className="py-2 px-4 text-right text-slate-400">{formatCurrencyPrecise(row.totalInterestPaid)}</td>
                      <td className="py-2 px-4 text-right text-white font-semibold">{formatCurrencyPrecise(row.remainingBalance)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="p-3 bg-slate-950 border-t border-slate-800 text-xs text-slate-500 text-center">
              Displaying first 120 months of accelerated amortization schedule.
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Annual Escrow Analysis (RESPA Section 10) */}
      {activeTab === 'escrow' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-cyan-400" />
              <span>Projected Annual Escrow Disbursements</span>
            </h3>

            <div className="space-y-2 text-xs">
              {srv.projectedAnnualDisbursements.map((item, idx) => (
                <div key={idx} className="p-2.5 bg-slate-950 border border-slate-800 rounded flex justify-between items-center">
                  <div>
                    <div className="font-medium text-slate-200">{item.category}</div>
                    <div className="text-[11px] text-slate-500">Scheduled Due Date: {item.dueDate}</div>
                  </div>
                  <div className="font-mono text-white font-semibold text-right tabular-nums">
                    {formatCurrency(item.amount)}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-slate-800 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>Total Annual Projected Disbursements:</span>
                <span className="font-mono text-white font-semibold">{formatCurrency(annualDisbursements)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Monthly Escrow Assessment:</span>
                <span className="font-mono text-slate-200">{formatCurrencyPrecise(monthlyEscrowNeed)}/mo</span>
              </div>
            </div>
          </div>

          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-white">RESPA Section 10 Cushion & Shortage Analysis</h3>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
                  <span className="text-slate-400">Current Escrow Balance:</span>
                  <span className="font-mono font-semibold text-white">{formatCurrencyPrecise(srv.currentEscrowBalance)}</span>
                </div>
                <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
                  <span className="text-slate-400">Statutory 2-Month Cushion Target:</span>
                  <span className="font-mono font-semibold text-slate-200">{formatCurrencyPrecise(requiredCushion)}</span>
                </div>
                <div className="flex justify-between p-2 bg-slate-950 border border-slate-800 rounded">
                  <span className="text-slate-400">Escrow Account Position:</span>
                  <span className={`font-mono font-bold ${escrowSurplusOrShortage >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {escrowSurplusOrShortage >= 0
                      ? `Surplus of ${formatCurrencyPrecise(escrowSurplusOrShortage)}`
                      : `Shortage of ${formatCurrencyPrecise(Math.abs(escrowSurplusOrShortage))}`}
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                Under RESPA regulations, servicers may maintain a cushion equal to one-sixth (2 months) of the total annual escrow disbursements.
                {escrowSurplusOrShortage >= 50
                  ? ' Surplus funds exceeding $50 will be automatically refunded to borrower upon annual statement anniversary.'
                  : ' Account cushion satisfies federal statutory parameters.'}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-800">
              <button
                onClick={() => addLoanNote(activeLoan.id, `Annual Escrow Statement generated. Projected T&I: ${formatCurrency(annualDisbursements)}, Cushion target: ${formatCurrencyPrecise(requiredCushion)}.`)}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded transition-colors"
              >
                Generate Official RESPA Escrow Disclosure Notice
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
