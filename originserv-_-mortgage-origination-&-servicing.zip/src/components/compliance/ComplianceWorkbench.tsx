import React, { useState } from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { LoanSelectorBar } from '../common/LoanSelectorBar';
import { formatCurrency, formatPercent } from '../../utils/mortgageMath';
import {
  ShieldCheck,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  AlertTriangle,
  Scale,
  Award,
  BookOpen,
} from 'lucide-react';

export const ComplianceWorkbench: React.FC = () => {
  const { loans, selectedLoan } = useMortgage();
  const [activeTab, setActiveTab] = useState<'qm' | 'hmda' | 'trid'>('qm');

  const loan = selectedLoan || loans[0];

  const handleExportHmdaCsv = () => {
    const headers = [
      'Loan_ID',
      'Borrower_Name',
      'Action_Taken_Code',
      'Action_Taken_Desc',
      'Loan_Type',
      'Loan_Purpose',
      'Loan_Amount',
      'Interest_Rate',
      'Rate_Spread_APOR',
      'Census_Tract',
      'QM_Status',
      'Points_Fees_Pct',
    ];

    const rows = loans.map(l => [
      l.id,
      `"${l.borrower.fullName}"`,
      l.compliance.hmdaActionTakenCode,
      l.stage === 'servicing' ? 'Loan Originated (1)' : 'Application in Underwriting (2)',
      l.terms.loanType,
      l.terms.loanPurpose,
      l.terms.loanAmount,
      l.terms.interestRate,
      l.compliance.rateSpread,
      l.compliance.censusTract,
      `"${l.compliance.qmStatus}"`,
      `${l.compliance.pointsAndFeesPercentage}%`,
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `HMDA_LAR_Filing_${new Date().getFullYear()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <LoanSelectorBar filterType="all" />

      {/* Compliance Overview KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">ATR / QM Conformance Rate</div>
          <div className="mt-1 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            100.0%
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>Dodd-Frank Section 1411</span>
            <span aria-hidden="true" className="mx-1.5">·</span>
            <span>Safe Harbor</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">HMDA LAR Tracked Entries</div>
          <div className="mt-1 text-2xl font-bold font-mono text-white tabular-nums">
            {loans.length} <span className="text-sm font-sans font-normal text-slate-400">records</span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>CFPB Regulation C Compliant</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Points & Fees 3% Test</div>
          <div className="mt-1 text-2xl font-bold font-mono text-cyan-400 tabular-nums">
            Passed
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>Max portfolio fee: 1.04%</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">TRID Timing Audits</div>
          <div className="mt-1 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            0 Violations
          </div>
          <div className="mt-2 text-xs text-slate-500">
            <span>3-Day Disclosure Rule Verified</span>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex items-center gap-1 border-b border-slate-800 text-xs">
        <button
          onClick={() => setActiveTab('qm')}
          className={`pb-2.5 px-3 font-medium transition-colors border-b-2 ${
            activeTab === 'qm'
              ? 'border-emerald-400 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Ability-to-Repay & Qualified Mortgage (ATR/QM)
        </button>
        <button
          onClick={() => setActiveTab('hmda')}
          className={`pb-2.5 px-3 font-medium transition-colors border-b-2 ${
            activeTab === 'hmda'
              ? 'border-emerald-400 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          HMDA Loan Application Register (LAR) & Export
        </button>
        <button
          onClick={() => setActiveTab('trid')}
          className={`pb-2.5 px-3 font-medium transition-colors border-b-2 ${
            activeTab === 'trid'
              ? 'border-emerald-400 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          TRID Timing & Changed Circumstance Audit
        </button>
      </div>

      {/* Tab 1: ATR / QM Engine */}
      {activeTab === 'qm' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 p-5 bg-slate-900/50 border border-slate-800 rounded-lg space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Qualified Mortgage (QM) Determination for {loan.id}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  12 CFR § 1026.43 Minimum Underwriting Standards
                </p>
              </div>
              <span className="font-mono text-emerald-400 text-xs font-semibold px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded">
                {loan.compliance.qmStatus}
              </span>
            </div>

            {/* Checklist */}
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-0.5 flex-1">
                  <div className="text-slate-200 font-medium">1. Points & Fees Cap Test (3.0% Rule)</div>
                  <div className="text-slate-400 text-[11px]">
                    Total points & fees are <span className="font-mono text-white">${loan.compliance.totalPointsAndFees}</span>, representing{' '}
                    <span className="font-mono text-emerald-400 font-medium">{loan.compliance.pointsAndFeesPercentage}%</span> of total loan amount, well below the statutory 3.0% threshold.
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-0.5 flex-1">
                  <div className="text-slate-200 font-medium">2. Toxic Features Prohibition Test</div>
                  <div className="text-slate-400 text-[11px]">
                    Verified: No negative amortization features, no balloon payment structure, no interest-only payment periods, and loan term does not exceed 30 years (360 months).
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-0.5 flex-1">
                  <div className="text-slate-200 font-medium">3. ATR Eight Underwriting Factors Verification</div>
                  <div className="text-slate-400 text-[11px]">
                    Underwriter verified: (1) Current employment income, (2) Assets, (3) Employment stability, (4) Monthly mortgage payment, (5) Simultaneous loans, (6) Monthly tax/insurance, (7) Total recurring debt liabilities, (8) DTI ratio.
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-0.5 flex-1">
                  <div className="text-slate-200 font-medium">4. APOR Rate Spread Safe Harbor Test</div>
                  <div className="text-slate-400 text-[11px]">
                    Annual Percentage Rate Spread is <span className="font-mono text-emerald-400">{loan.compliance.rateSpread}%</span> above the Average Prime Offer Rate (APOR). Since spread is &lt; 1.50 percentage points, the loan conclusively qualifies for QM Safe Harbor legal presumption.
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Legal Defense & Audit Summary */}
          <div className="p-5 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4 flex flex-col justify-between">
            <div className="space-y-3 text-xs">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Scale className="w-4 h-4 text-emerald-400" />
                <span>Statutory Safe Harbor Protection</span>
              </h3>
              <p className="text-slate-300 leading-relaxed">
                By originating under the CFPB General QM definition with APOR spread under 1.50%, the lender and broker are granted the strongest legal protection under Truth in Lending Act (TILA).
              </p>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded space-y-1.5 font-mono text-[11px]">
                <div className="text-slate-400">APOR Benchmark Rate: <span className="text-slate-200">6.53%</span></div>
                <div className="text-slate-400">Loan APR: <span className="text-white">{loan.terms.apr}%</span></div>
                <div className="text-slate-400">Calculated Spread: <span className="text-emerald-400">+{loan.compliance.rateSpread}%</span></div>
                <div className="text-slate-400">Threshold for Rebuttable: <span className="text-amber-400">&ge; 1.50%</span></div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800">
              <div className="text-[11px] text-slate-500">
                Audit certified by OriginServ Regulatory Compliance Engine. Form CFPB-QM-2026.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: HMDA LAR Table & Export */}
      {activeTab === 'hmda' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-slate-900/50 border border-slate-800 rounded-lg">
            <div>
              <h3 className="text-sm font-semibold text-white">CFPB HMDA Loan Application Register (LAR)</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Annual filing dataset pursuant to 12 CFR Part 1003 (Regulation C).
              </p>
            </div>
            <button
              onClick={handleExportHmdaCsv}
              className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs rounded transition-colors whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export HMDA LAR (CSV)</span>
            </button>
          </div>

          <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-900/30">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950 text-slate-400 font-medium">
                    <th className="py-2.5 px-4">Application / ULI</th>
                    <th className="py-2.5 px-4">Borrower</th>
                    <th className="py-2.5 px-4">Action Taken</th>
                    <th className="py-2.5 px-4 text-right">Loan Amount</th>
                    <th className="py-2.5 px-4">Product / Purpose</th>
                    <th className="py-2.5 px-4 text-right">Rate Spread</th>
                    <th className="py-2.5 px-4">Census Tract</th>
                    <th className="py-2.5 px-4">QM Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {loans.map((l) => (
                    <tr key={l.id} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-4 text-white font-medium">{l.id}</td>
                      <td className="py-2.5 px-4 font-sans text-slate-200">{l.borrower.fullName}</td>
                      <td className="py-2.5 px-4 font-sans">
                        <span className="text-emerald-400 text-[11px]">
                          Code {l.compliance.hmdaActionTakenCode} (Originated)
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-right text-white tabular-nums">
                        {formatCurrency(l.terms.loanAmount)}
                      </td>
                      <td className="py-2.5 px-4 font-sans text-slate-300">
                        {l.terms.loanType} · {l.terms.loanPurpose}
                      </td>
                      <td className="py-2.5 px-4 text-right text-emerald-400 tabular-nums">
                        +{l.compliance.rateSpread}%
                      </td>
                      <td className="py-2.5 px-4 text-slate-400">{l.compliance.censusTract}</td>
                      <td className="py-2.5 px-4 font-sans text-slate-300">{l.compliance.qmStatus}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: TRID Timing & Changed Circumstance Audit */}
      {activeTab === 'trid' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
            <h3 className="text-sm font-semibold text-white">TRID Disclosure Timing Requirements</h3>
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded space-y-1">
                <div className="flex items-center justify-between text-slate-200 font-medium">
                  <span>1. Loan Estimate (LE) 3-Day Rule</span>
                  <span className="text-emerald-400 font-mono text-[11px]">Satisfied</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Delivered within 3 general business days of receiving the 6 pieces of information: Name, Income, SSN, Property Address, Estimated Value, Loan Amount.
                </p>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded space-y-1">
                <div className="flex items-center justify-between text-slate-200 font-medium">
                  <span>2. Intent to Proceed Prior to Fee Collection</span>
                  <span className="text-emerald-400 font-mono text-[11px]">Satisfied</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Borrower confirmed written intent to proceed before any appraisal or processing fees were charged. Only bona fide credit report fee was charged prior.
                </p>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded space-y-1">
                <div className="flex items-center justify-between text-slate-200 font-medium">
                  <span>3. Closing Disclosure (CD) 3-Day Waiting Rule</span>
                  <span className="text-emerald-400 font-mono text-[11px]">Satisfied</span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  Delivered at least 3 precise business days (all calendar days except Sundays and federal holidays) prior to consummation.
                </p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
            <h3 className="text-sm font-semibold text-white">Valid Changed Circumstances Log (COC)</h3>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200">Revision Event #1: Rate Lock Confirmation</span>
                <span className="text-slate-500 font-mono text-[11px]">2026-09-22</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Borrower executed 45-day rate lock agreement at 6.625%. Revised Loan Estimate issued within 3 business days of lock execution pursuant to 12 CFR § 1026.19(e)(3)(iv)(D).
              </p>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200">Revision Event #2: Settlement Agent Title Re-quote</span>
                <span className="text-slate-500 font-mono text-[11px]">2026-09-24</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Title commitment reflected endorsement for PUD. Adjusted within 10% aggregate tolerance limit without trigger for cure.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
