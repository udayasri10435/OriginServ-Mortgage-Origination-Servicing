import React, { useState } from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { LoanSelectorBar } from '../common/LoanSelectorBar';
import { UnderwritingCondition } from '../../types/mortgage';
import {
  calculateMonthlyPI,
  calculateMonthlyPMI,
  calculateFrontEndDTI,
  calculateBackEndDTI,
  calculateLTV,
  formatCurrency,
  formatPercent,
} from '../../utils/mortgageMath';
import {
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileCheck,
  Upload,
  Plus,
  RefreshCw,
  Send,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

export const UnderwritingWorkbench: React.FC = () => {
  const {
    selectedLoan,
    runAUS,
    addCondition,
    updateConditionStatus,
    issueClearToClose,
    advanceStage,
    addLoanNote,
    currentRole,
    setCurrentTab,
  } = useMortgage();

  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'ALL' | 'PTD' | 'PTC' | 'PTF'>('ALL');
  const [newCondTitle, setNewCondTitle] = useState('');
  const [newCondDesc, setNewCondDesc] = useState('');
  const [newCondCat, setNewCondCat] = useState<'PTD' | 'PTC' | 'PTF'>('PTD');
  const [showAddModal, setShowAddModal] = useState(false);
  const [noteInput, setNoteInput] = useState('');
  const [isSimulatingUpload, setIsSimulatingUpload] = useState<string | null>(null);

  if (!selectedLoan) {
    return (
      <div className="text-center py-20 text-slate-500">
        Please select a loan application to view underwriting workbench.
      </div>
    );
  }

  // Calculations
  const loan = selectedLoan;
  const ltv = calculateLTV(loan.terms.loanAmount, loan.property.purchasePrice || loan.property.appraisedValue);
  const monthlyPI = calculateMonthlyPI(loan.terms.loanAmount, loan.terms.interestRate, loan.terms.termMonths);
  const monthlyTax = loan.property.annualPropertyTax / 12;
  const monthlyIns = loan.property.annualHazardInsurance / 12;
  const monthlyPMI = calculateMonthlyPMI(loan.terms.loanAmount, loan.property.purchasePrice, loan.borrower.ficoScore);
  const totalHousing = monthlyPI + monthlyTax + monthlyIns + loan.property.monthlyHOA + monthlyPMI;

  const totalIncome = loan.borrower.monthlyBaseIncome + loan.borrower.monthlyOtherIncome;
  const totalDebts = loan.borrower.monthlyDebts.reduce((sum, d) => sum + d.monthlyPayment, 0);

  const frontDTI = calculateFrontEndDTI(totalHousing, totalIncome);
  const backDTI = calculateBackEndDTI(totalHousing, totalDebts, totalIncome);

  const totalLiquidAssets = loan.borrower.liquidAssets.reduce((sum, a) => sum + a.amount, 0);
  const monthsReserves = totalHousing > 0 ? (totalLiquidAssets / totalHousing).toFixed(1) : '0';

  // Filter conditions
  const conditions = loan.conditions || [];
  const filteredConditions = conditions.filter(c => {
    if (activeCategoryFilter === 'ALL') return true;
    return c.category === activeCategoryFilter;
  });

  const ptdPending = conditions.filter(c => c.category === 'PTD' && c.status !== 'cleared' && c.status !== 'waived').length;
  const ptcPending = conditions.filter(c => c.category === 'PTC' && c.status !== 'cleared' && c.status !== 'waived').length;
  const ptfPending = conditions.filter(c => c.category === 'PTF' && c.status !== 'cleared' && c.status !== 'waived').length;
  const totalPending = ptdPending + ptcPending + ptfPending;

  const handleAddCondition = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCondTitle.trim()) return;
    addCondition(loan.id, {
      title: newCondTitle,
      description: newCondDesc,
      category: newCondCat,
      status: 'pending',
    });
    setNewCondTitle('');
    setNewCondDesc('');
    setShowAddModal(false);
  };

  const handleSimulateUpload = (condId: string) => {
    setIsSimulatingUpload(condId);
    setTimeout(() => {
      updateConditionStatus(loan.id, condId, 'submitted');
      addLoanNote(loan.id, `Borrower/Broker uploaded verification document for condition ${condId}.`);
      setIsSimulatingUpload(null);
    }, 600);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteInput.trim()) return;
    addLoanNote(loan.id, noteInput);
    setNoteInput('');
  };

  return (
    <div className="space-y-6">
      {/* Active Loan Switcher Bar */}
      <LoanSelectorBar filterType="origination" />

      {/* Underwriting Health & Capacity Cockpit */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-[11px] text-slate-400">Credit Score (FICO)</div>
          <div className="mt-1 text-xl font-bold font-mono text-emerald-400 tabular-nums">
            {loan.borrower.ficoScore}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {loan.borrower.ficoScore >= 740 ? 'Tier 1 Prime' : loan.borrower.ficoScore >= 680 ? 'Standard Agency' : 'FHA / Sub-Tier'}
          </div>
        </div>

        <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-[11px] text-slate-400">Loan-to-Value (LTV)</div>
          <div className="mt-1 text-xl font-bold font-mono text-white tabular-nums">
            {ltv.toFixed(1)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {ltv <= 80 ? 'No PMI Required' : `PMI Est: $${monthlyPMI}/mo`}
          </div>
        </div>

        <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-[11px] text-slate-400">Front-End DTI</div>
          <div className={`mt-1 text-xl font-bold font-mono tabular-nums ${frontDTI > 28 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {frontDTI}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Housing / Income (28% Benchmark)
          </div>
        </div>

        <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-[11px] text-slate-400">Back-End DTI</div>
          <div className={`mt-1 text-xl font-bold font-mono tabular-nums ${backDTI > 43 ? 'text-rose-400' : 'text-emerald-400'}`}>
            {backDTI}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Total Debt (43.0% QM Cap)
          </div>
        </div>

        <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-[11px] text-slate-400">Post-Closing Reserves</div>
          <div className="mt-1 text-xl font-bold font-mono text-white tabular-nums">
            {monthsReserves} <span className="text-xs font-sans text-slate-400">mo</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {formatCurrency(totalLiquidAssets)} liquid
          </div>
        </div>

        <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="text-[11px] text-slate-400">Total Monthly PITI</div>
          <div className="mt-1 text-xl font-bold font-mono text-cyan-400 tabular-nums">
            {formatCurrency(totalHousing)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            P&I: {formatCurrency(monthlyPI)}
          </div>
        </div>
      </div>

      {/* Main Grid: Left = AUS & Conditions; Right = Decision Workbench & File Notes */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: AUS Engine Findings & Conditions Manager */}
        <div className="lg:col-span-2 space-y-6">
          {/* Automated Underwriting System (AUS) Card */}
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">
                  Automated Underwriting Engine ({loan.aus.system})
                </h3>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-400 font-mono">Case #{loan.aus.caseFileId}</span>
                <button
                  onClick={() => runAUS(loan.id)}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Re-Evaluate AUS</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs border-y border-slate-800/80 py-2">
              <span className="text-slate-400">Decision Status:</span>
              <span className={`font-semibold font-mono ${loan.aus.recommendation === 'Approve/Eligible' ? 'text-emerald-400' : 'text-amber-400'}`}>
                {loan.aus.recommendation}
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-slate-400">Run Date: {loan.aus.runDate}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-slate-400">Agency Guideline: Conforming Fannie / Freddie</span>
            </div>

            <div className="space-y-1.5 text-xs text-slate-300">
              {loan.aus.findings.map((finding, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <span className="text-emerald-400 shrink-0 mt-0.5">•</span>
                  <span>{finding}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Underwriting Conditions Management */}
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Underwriting Conditions & Stipulations
                </h3>
                <div className="text-xs text-slate-400 mt-0.5">
                  <span>{conditions.length} total</span>
                  <span aria-hidden="true" className="mx-1.5">·</span>
                  <span className={totalPending > 0 ? 'text-amber-400' : 'text-emerald-400'}>
                    {totalPending} pending clearance
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Segmented Filter */}
                <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded text-xs">
                  <button
                    onClick={() => setActiveCategoryFilter('ALL')}
                    className={`px-2 py-1 rounded transition-colors ${
                      activeCategoryFilter === 'ALL' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    All ({conditions.length})
                  </button>
                  <button
                    onClick={() => setActiveCategoryFilter('PTD')}
                    className={`px-2 py-1 rounded transition-colors ${
                      activeCategoryFilter === 'PTD' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    PTD ({ptdPending})
                  </button>
                  <button
                    onClick={() => setActiveCategoryFilter('PTC')}
                    className={`px-2 py-1 rounded transition-colors ${
                      activeCategoryFilter === 'PTC' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    PTC ({ptcPending})
                  </button>
                  <button
                    onClick={() => setActiveCategoryFilter('PTF')}
                    className={`px-2 py-1 rounded transition-colors ${
                      activeCategoryFilter === 'PTF' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    PTF ({ptfPending})
                  </button>
                </div>

                <button
                  onClick={() => setShowAddModal(true)}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 rounded transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Condition</span>
                </button>
              </div>
            </div>

            {/* Conditions List */}
            <div className="space-y-2">
              {filteredConditions.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-xs">
                  No conditions in this category.
                </div>
              ) : (
                filteredConditions.map((cond) => {
                  const isCleared = cond.status === 'cleared';
                  const isSubmitted = cond.status === 'submitted';
                  const isPending = cond.status === 'pending';

                  return (
                    <div
                      key={cond.id}
                      className="p-3 bg-slate-950 border border-slate-800/80 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[11px] font-semibold text-slate-400">
                            [{cond.category}]
                          </span>
                          <span className="font-medium text-slate-200">{cond.title}</span>
                          <span className="text-[11px]">
                            {isCleared && <span className="text-emerald-400 font-medium">Cleared</span>}
                            {isSubmitted && <span className="text-cyan-400 font-medium">Submitted for UW Review</span>}
                            {isPending && <span className="text-amber-400 font-medium">Pending Documentation</span>}
                          </span>
                        </div>
                        <p className="text-slate-400 text-[11px]">{cond.description}</p>
                        {cond.requiredDocumentName && (
                          <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-0.5">
                            <FileCheck className="w-3.5 h-3.5 text-slate-400" />
                            <span>Attached Doc: {cond.requiredDocumentName}</span>
                            {cond.clearedBy && <span>· Cleared by {cond.clearedBy} ({cond.clearedAt})</span>}
                          </div>
                        )}
                      </div>

                      {/* Condition Action Buttons */}
                      <div className="flex items-center gap-2 shrink-0">
                        {/* Broker Upload Simulation */}
                        {isPending && (
                          <button
                            onClick={() => handleSimulateUpload(cond.id)}
                            disabled={isSimulatingUpload === cond.id}
                            className="flex items-center gap-1 px-2.5 py-1 text-slate-300 hover:text-white bg-slate-900 border border-slate-700 hover:border-slate-600 rounded transition-colors"
                          >
                            <Upload className="w-3 h-3 text-cyan-400" />
                            <span>{isSimulatingUpload === cond.id ? 'Uploading...' : 'Upload Doc'}</span>
                          </button>
                        )}

                        {/* Lender Underwriting Sign-Off */}
                        {currentRole === 'lender' && (
                          <>
                            {!isCleared && (
                              <button
                                onClick={() => updateConditionStatus(loan.id, cond.id, 'cleared')}
                                className="flex items-center gap-1 px-2.5 py-1 text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 rounded transition-colors"
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Sign Off & Clear</span>
                              </button>
                            )}
                            {isCleared && (
                              <button
                                onClick={() => updateConditionStatus(loan.id, cond.id, 'pending')}
                                className="text-slate-500 hover:text-slate-300 px-2 py-1 text-[11px]"
                              >
                                Re-Open
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Underwriting Decision Workbench & File Notes */}
        <div className="space-y-6">
          {/* Decision Station Card */}
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
            <h3 className="text-sm font-semibold text-white flex items-center justify-between">
              <span>Underwriting Decision Desk</span>
              <span className="text-xs font-normal text-slate-400 font-mono uppercase">
                {loan.stage.replace(/_/g, ' ')}
              </span>
            </h3>

            <div className="space-y-2 text-xs">
              <div className="p-2.5 bg-slate-950 border border-slate-800 rounded space-y-1">
                <div className="text-slate-400 font-medium">Clear to Close (CTC) Readiness:</div>
                <div className="text-slate-300 text-[11px]">
                  {ptdPending > 0
                    ? `Cannot issue CTC: ${ptdPending} Prior-to-Doc (PTD) conditions must be cleared first.`
                    : 'All PTD conditions are satisfied. File is eligible for Clear to Close & TRID Closing Package!'}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 space-y-2">
                <button
                  onClick={() => issueClearToClose(loan.id)}
                  disabled={ptdPending > 0}
                  className={`w-full py-2 px-3 text-xs font-semibold rounded transition-colors flex items-center justify-center gap-2 ${
                    ptdPending === 0
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Issue Clear to Close (CTC)</span>
                </button>

                <button
                  onClick={() => {
                    advanceStage(loan.id, 'conditional_approval');
                    addLoanNote(loan.id, 'Underwriter issued Conditional Approval with listed PTD/PTC items.');
                  }}
                  className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded transition-colors"
                >
                  Issue Conditional Approval
                </button>

                <button
                  onClick={() => {
                    setCurrentTab('closing');
                  }}
                  className="w-full py-2 px-3 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/20 text-xs font-medium rounded transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>Proceed to TRID Closing Desk</span>
                  <span aria-hidden="true">→</span>
                </button>
              </div>
            </div>
          </div>

          {/* Underwriting Notes & Audit Trail */}
          <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-slate-400" />
              <span>Underwriter & Broker Audit Trail</span>
            </h3>

            <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
              {loan.notes.map((note) => (
                <div key={note.id} className="p-2.5 bg-slate-950 border border-slate-800/80 rounded text-xs space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-medium text-slate-300">{note.author} ({note.role})</span>
                    <span className="font-mono text-slate-500">{note.timestamp}</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">{note.content}</p>
                </div>
              ))}
            </div>

            {/* Note Input */}
            <form onSubmit={handleAddNote} className="flex gap-2">
              <input
                type="text"
                placeholder="Log note or underwriter comment..."
                value={noteInput}
                onChange={(e) => setNoteInput(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded text-xs transition-colors flex items-center gap-1"
              >
                <Send className="w-3 h-3" />
                <span>Log</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Add Condition Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-bold text-white">Add Underwriting Stipulation</h3>
            <form onSubmit={handleAddCondition} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Category</label>
                <select
                  value={newCondCat}
                  onChange={(e) => setNewCondCat(e.target.value as 'PTD' | 'PTC' | 'PTF')}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="PTD">PTD (Prior to Documents)</option>
                  <option value="PTC">PTC (Prior to Closing)</option>
                  <option value="PTF">PTF (Prior to Funding)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Condition Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Flood Insurance Declaration Page"
                  value={newCondTitle}
                  onChange={(e) => setNewCondTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Detailed Requirements</label>
                <textarea
                  rows={3}
                  placeholder="Specific requirements for borrower or settlement agent..."
                  value={newCondDesc}
                  onChange={(e) => setNewCondDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded"
                >
                  Save Stipulation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
