import React, { useState } from 'react';
import { useMortgage } from '../../context/MortgageContext';
import { LoanSelectorBar } from '../common/LoanSelectorBar';
import { evaluateTridTolerances, formatCurrency, formatPercent, formatCurrencyPrecise } from '../../utils/mortgageMath';
import {
  FileText,
  AlertTriangle,
  CheckCircle2,
  Clock,
  DollarSign,
  ArrowRight,
  ShieldAlert,
  Send,
  Download,
  Building,
} from 'lucide-react';

export const ClosingWorkbench: React.FC = () => {
  const { selectedLoan, updateTridFee, fundAndTransferToServicing, setCurrentTab, addLoanNote } = useMortgage();
  const [wireReconciled, setWireReconciled] = useState(false);
  const [showPackageModal, setShowPackageModal] = useState(false);
  const [selectedDocToView, setSelectedDocToView] = useState<string | null>(null);

  if (!selectedLoan) {
    return (
      <div className="text-center py-20 text-slate-500">
        Please select a loan application to view Closing & TRID Disclosures.
      </div>
    );
  }

  const loan = selectedLoan;
  const toleranceEval = evaluateTridTolerances(loan.tridFees);

  // Settlement math
  const loanAmount = loan.terms.loanAmount;
  const downPayment = loan.terms.downPayment;
  const totalInboundFunds = loanAmount + downPayment;
  const totalClosingCosts = loan.tridFees.reduce((sum, f) => sum + (f.paidBy === 'Borrower' ? f.closingDisclosureAmount : 0), 0);
  const purchasePrice = loan.property.purchasePrice;
  const netWireToTitle = loanAmount - (loan.tridFees.find(f => f.category === 'origination')?.closingDisclosureAmount || 0);

  const handleCureViolation = () => {
    // Automatically adjust lender origination fee or apply lender credit to zero out overage
    if (loan.tridFees.length > 0) {
      const origFee = loan.tridFees[0];
      const curedCdAmount = Math.max(0, origFee.loanEstimateAmount - toleranceEval.totalCureRequired);
      updateTridFee(loan.id, origFee.id, origFee.loanEstimateAmount, curedCdAmount);
      addLoanNote(loan.id, `TRID Cure applied: Lender credit of ${formatCurrencyPrecise(toleranceEval.totalCureRequired)} credited to borrower to eliminate tolerance variance.`);
    }
  };

  const handleFundLoan = () => {
    fundAndTransferToServicing(loan.id);
    setCurrentTab('servicing');
  };

  return (
    <div className="space-y-6">
      <LoanSelectorBar filterType="origination" />

      {/* TRID Regulatory Notice & Statutory Waiting Clock */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white">
              TRID 3-Business-Day Statutory Consummation Clock
            </h3>
          </div>
          <div className="text-xs text-slate-400">
            <span>Closing Disclosure (CD) Delivered: <span className="text-slate-200 font-mono">2026-09-26</span></span>
            <span aria-hidden="true" className="mx-2">·</span>
            <span>Waiting Period Status: <span className="text-emerald-400 font-medium">Statutory 3-Day Wait Expired</span></span>
            <span aria-hidden="true" className="mx-2">·</span>
            <span>Eligible for Consummation: <span className="text-slate-200 font-mono">Immediately</span></span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {toleranceEval.isCompliant ? (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 text-xs font-medium">
              <CheckCircle2 className="w-4 h-4" />
              <span>TRID Tolerances Passed</span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-500/10 border border-rose-500/20 rounded text-rose-400 text-xs font-medium">
                <AlertTriangle className="w-4 h-4" />
                <span>Cure Required: {formatCurrencyPrecise(toleranceEval.totalCureRequired)}</span>
              </div>
              <button
                onClick={handleCureViolation}
                className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs rounded transition-colors"
              >
                Apply Lender Cure Credit
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Side-by-side LE vs CD Fee Reconciliation Table */}
      <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-900/40">
        <div className="p-4 border-b border-slate-800 bg-slate-900/80 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Fee Variance Ledger: Loan Estimate (LE) vs Closing Disclosure (CD)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Automated TRID 0% and 10% tolerance buckets with audit verification.
            </p>
          </div>
          <div className="text-xs text-slate-400 font-mono tabular-nums">
            Total Closing Costs: <span className="text-white font-semibold">{formatCurrency(totalClosingCosts)}</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/40 text-slate-400 font-medium">
                <th className="py-2.5 px-4">Fee Item & Service</th>
                <th className="py-2.5 px-4">Tolerance Rule</th>
                <th className="py-2.5 px-4 text-right">Loan Estimate (LE)</th>
                <th className="py-2.5 px-4 text-right">Closing Disclosure (CD)</th>
                <th className="py-2.5 px-4 text-right">Variance ($)</th>
                <th className="py-2.5 px-4 text-center">Status</th>
                <th className="py-2.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loan.tridFees.map((fee) => {
                const variance = fee.closingDisclosureAmount - fee.loanEstimateAmount;
                let isViolated = false;

                if (fee.toleranceCategory === 'zero' && variance > 0) {
                  isViolated = true;
                }

                return (
                  <tr key={fee.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 px-4">
                      <div className="font-medium text-slate-200">{fee.name}</div>
                      <div className="text-[11px] text-slate-500 capitalize">{fee.category.replace(/_/g, ' ')} · Paid by {fee.paidBy}</div>
                    </td>

                    <td className="py-2.5 px-4 font-mono text-[11px]">
                      {fee.toleranceCategory === 'zero' && (
                        <span className="text-amber-400 font-medium">0% Strict Tolerance</span>
                      )}
                      {fee.toleranceCategory === 'ten_percent' && (
                        <span className="text-cyan-400">10% Aggregate</span>
                      )}
                      {fee.toleranceCategory === 'unlimited' && (
                        <span className="text-slate-400">Unlimited Tolerance</span>
                      )}
                    </td>

                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-300">
                      {formatCurrencyPrecise(fee.loanEstimateAmount)}
                    </td>

                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-white font-medium">
                      {formatCurrencyPrecise(fee.closingDisclosureAmount)}
                    </td>

                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">
                      {variance === 0 ? (
                        <span className="text-slate-500">$0.00</span>
                      ) : variance > 0 ? (
                        <span className={isViolated ? 'text-rose-400 font-semibold' : 'text-slate-300'}>
                          +{formatCurrencyPrecise(variance)}
                        </span>
                      ) : (
                        <span className="text-emerald-400">
                          -{formatCurrencyPrecise(Math.abs(variance))}
                        </span>
                      )}
                    </td>

                    <td className="py-2.5 px-4 text-center">
                      {isViolated ? (
                        <span className="text-rose-400 text-[11px] font-medium">Tolerance Violation</span>
                      ) : (
                        <span className="text-emerald-400 text-[11px]">Compliant</span>
                      )}
                    </td>

                    <td className="py-2.5 px-4 text-right">
                      {/* Allow simulating a fee change to demonstrate TRID auditor */}
                      <button
                        onClick={() => {
                          const newCd = fee.closingDisclosureAmount + 100;
                          updateTridFee(loan.id, fee.id, fee.loanEstimateAmount, newCd);
                        }}
                        className="text-slate-500 hover:text-slate-300 text-[11px] px-1.5 py-0.5 hover:bg-slate-800 rounded"
                        title="Simulate fee increase to test tolerance auditor"
                      >
                        +$100
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bottom 2 Columns: Settlement Wire Reconciliation & Closing Package */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Settlement & Wire Reconciliation */}
        <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-white">Settlement Wire & Disbursement Ledger</h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">Title: First American Title</span>
          </div>

          <div className="space-y-2 text-xs divide-y divide-slate-800/80">
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">Total Purchase Consideration:</span>
              <span className="font-mono text-white tabular-nums">{formatCurrency(purchasePrice)}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">Approved Loan Amount (Mortgage):</span>
              <span className="font-mono text-emerald-400 tabular-nums">{formatCurrency(loanAmount)}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">Borrower Cash to Close (Down + Prepaids):</span>
              <span className="font-mono text-white tabular-nums">{formatCurrency(downPayment + totalClosingCosts)}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">Lender Net Funding Wire to Escrow:</span>
              <span className="font-mono text-cyan-400 font-semibold tabular-nums">{formatCurrency(netWireToTitle)}</span>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between border-t border-slate-800">
            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={wireReconciled}
                onChange={(e) => setWireReconciled(e.target.checked)}
                className="rounded border-slate-700 bg-slate-950 text-emerald-500 focus:ring-0"
              />
              <span>Closing Wire Instructions Verified & Reconciled</span>
            </label>

            <span className="text-[11px] text-slate-500">Fedwire ABA: 121000358</span>
          </div>
        </div>

        {/* Closing Package & Execution Desk */}
        <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">Statutory Closing Document Package</h3>
              </div>
              <span className="text-xs text-emerald-400 font-medium">Docs Generated</span>
            </div>

            <div className="mt-3 space-y-2 text-xs">
              <div
                onClick={() => { setSelectedDocToView('promissory_note'); setShowPackageModal(true); }}
                className="p-2.5 bg-slate-950 hover:bg-slate-800/70 border border-slate-800 rounded flex items-center justify-between cursor-pointer transition-colors"
              >
                <div>
                  <div className="font-medium text-slate-200">1. Uniform Fixed-Rate Promissory Note</div>
                  <div className="text-[11px] text-slate-400">Fannie Mae / Freddie Mac Form 3200 · 30-Year Fixed</div>
                </div>
                <span className="text-xs text-slate-400 hover:text-white">Review</span>
              </div>

              <div
                onClick={() => { setSelectedDocToView('deed_of_trust'); setShowPackageModal(true); }}
                className="p-2.5 bg-slate-950 hover:bg-slate-800/70 border border-slate-800 rounded flex items-center justify-between cursor-pointer transition-colors"
              >
                <div>
                  <div className="font-medium text-slate-200">2. Deed of Trust / Security Instrument</div>
                  <div className="text-[11px] text-slate-400">State Specific Form 3048 · County Recorder Endorsement</div>
                </div>
                <span className="text-xs text-slate-400 hover:text-white">Review</span>
              </div>

              <div
                onClick={() => { setSelectedDocToView('escrow_agreement'); setShowPackageModal(true); }}
                className="p-2.5 bg-slate-950 hover:bg-slate-800/70 border border-slate-800 rounded flex items-center justify-between cursor-pointer transition-colors"
              >
                <div>
                  <div className="font-medium text-slate-200">3. Initial Escrow Disclosure & First Payment Letter</div>
                  <div className="text-[11px] text-slate-400">RESPA Section 10 Escrow Schedule & Servicing Transfer Notice</div>
                </div>
                <span className="text-xs text-slate-400 hover:text-white">Review</span>
              </div>
            </div>
          </div>

          {/* Consummation & Servicing Transfer Action */}
          <div className="pt-3 border-t border-slate-800 space-y-2">
            <button
              onClick={handleFundLoan}
              disabled={!toleranceEval.isCompliant}
              className={`w-full py-2.5 px-4 text-xs font-semibold rounded transition-colors flex items-center justify-center gap-2 ${
                toleranceEval.isCompliant
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer shadow-lg'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Fund Loan & Transfer to Active Servicing Portfolio</span>
            </button>
            <div className="text-center text-[11px] text-slate-500">
              Upon funding, file will automatically onboard into the Servicing Ledger with MERS MIN registration.
            </div>
          </div>
        </div>
      </div>

      {/* Document Review Modal */}
      {showPackageModal && selectedDocToView && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-2xl max-h-[85vh] p-6 flex flex-col shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                {selectedDocToView === 'promissory_note' && 'Uniform Fixed-Rate Promissory Note'}
                {selectedDocToView === 'deed_of_trust' && 'Deed of Trust / Security Instrument'}
                {selectedDocToView === 'escrow_agreement' && 'Initial Escrow Statement & First Payment Letter'}
              </h3>
              <button
                onClick={() => setShowPackageModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Close
              </button>
            </div>

            <div className="flex-1 overflow-y-auto font-mono text-xs text-slate-300 bg-slate-950 p-4 rounded border border-slate-800 space-y-3 leading-relaxed">
              <p>BORROWER: {loan.borrower.fullName}</p>
              <p>PROPERTY ADDRESS: {loan.property.streetAddress}, {loan.property.city}, {loan.property.state} {loan.property.zipCode}</p>
              <p>PRINCIPAL AMOUNT: {formatCurrency(loan.terms.loanAmount)}</p>
              <p>INTEREST RATE: {formatPercent(loan.terms.interestRate)} per annum</p>
              <hr className="border-slate-800" />
              {selectedDocToView === 'promissory_note' && (
                <div>
                  <p className="font-semibold text-white">1. BORROWER&apos;S PROMISE TO PAY</p>
                  <p className="mt-1">In return for a loan that I have received, I promise to pay U.S. {formatCurrency(loan.terms.loanAmount)} (this amount is called &quot;Principal&quot;), plus interest, to the order of the Lender. The Lender is OriginServ Capital Corp.</p>
                  <p className="mt-2 font-semibold text-white">2. MONTHLY PAYMENTS</p>
                  <p className="mt-1">I will pay principal and interest by making a payment every month. I will make my monthly payment on the 1st day of each month beginning November 1, 2026. My monthly payment will be in the amount of U.S. {formatCurrency(loanAmount > 0 ? (loanAmount * 0.0064) : 0)}.</p>
                </div>
              )}
              {selectedDocToView === 'deed_of_trust' && (
                <div>
                  <p className="font-semibold text-white">TRANSFER OF RIGHTS IN THE PROPERTY</p>
                  <p className="mt-1">The borrower irrevocably grants and conveys to Trustee, in trust, with power of sale, the property situated in the County of Multnomah, State of Oregon, commonly known as {loan.property.streetAddress}.</p>
                  <p className="mt-2">TOGETHER WITH all the improvements now or hereafter erected on the property, and all easements, appurtenances, and fixtures now or hereafter a part of the property.</p>
                </div>
              )}
              {selectedDocToView === 'escrow_agreement' && (
                <div>
                  <p className="font-semibold text-white">RESPA SECTION 10 INITIAL ESCROW ACCOUNT STATEMENT</p>
                  <p className="mt-1">This is an estimate of activity in your escrow account during the coming year based on payments we anticipate making on your behalf.</p>
                  <p className="mt-2">County Property Taxes: ${loan.property.annualPropertyTax} / year</p>
                  <p>Homeowner Hazard Insurance: ${loan.property.annualHazardInsurance} / year</p>
                  <p>Required Minimum Cushion: 2 months disbursements.</p>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowPackageModal(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
