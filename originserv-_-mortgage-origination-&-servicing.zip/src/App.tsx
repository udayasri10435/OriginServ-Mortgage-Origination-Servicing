import React, { useState } from 'react';
import { MortgageProvider, useMortgage } from './context/MortgageContext';
import { Header } from './components/common/Header';
import { PipelineView } from './components/pipeline/PipelineView';
import { UnderwritingWorkbench } from './components/underwriting/UnderwritingWorkbench';
import { ClosingWorkbench } from './components/closing/ClosingWorkbench';
import { ServicingWorkbench } from './components/servicing/ServicingWorkbench';
import { ComplianceWorkbench } from './components/compliance/ComplianceWorkbench';
import { BrokerPricingDesk } from './components/broker/BrokerPricingDesk';
import { NewLoanModal } from './components/application/NewLoanModal';

const AppContent: React.FC = () => {
  const { currentTab } = useMortgage();
  const [isNewLoanModalOpen, setIsNewLoanModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <Header onOpenNewLoanModal={() => setIsNewLoanModalOpen(true)} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'pipeline' && (
          <PipelineView onOpenNewLoanModal={() => setIsNewLoanModalOpen(true)} />
        )}
        {currentTab === 'underwriting' && <UnderwritingWorkbench />}
        {currentTab === 'closing' && <ClosingWorkbench />}
        {currentTab === 'servicing' && <ServicingWorkbench />}
        {currentTab === 'compliance' && <ComplianceWorkbench />}
        {currentTab === 'pricing' && <BrokerPricingDesk />}
      </main>

      {/* Footer with clean copyright and domain attribution */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">OriginServ</span>
            <span>· Mortgage Origination & Servicing Architecture</span>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <span>1003 / MISMO 3.4 Standards</span>
            <span aria-hidden="true">·</span>
            <span>CFPB TRID & Dodd-Frank ATR/QM Verified</span>
            <span aria-hidden="true">·</span>
            <span>RESPA Section 10 Escrow Custody</span>
          </div>
        </div>
      </footer>

      {/* 1003 New Loan Intake Modal */}
      <NewLoanModal
        isOpen={isNewLoanModalOpen}
        onClose={() => setIsNewLoanModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <MortgageProvider>
      <AppContent />
    </MortgageProvider>
  );
}
