export type UserRole = 'lender' | 'broker';

export type LoanStage = 
  | 'lead'
  | 'application'
  | 'processing'
  | 'underwriting'
  | 'conditional_approval'
  | 'clear_to_close'
  | 'closing'
  | 'funded'
  | 'servicing';

export type LoanType = 'Conventional' | 'FHA' | 'VA' | 'Jumbo' | 'USDA';
export type LoanPurpose = 'Purchase' | 'Rate & Term Refi' | 'Cash-Out Refi';
export type PropertyType = 'Single Family' | 'Condominium' | 'Townhome' | 'Multi-Family (2-4 Units)';
export type OccupancyType = 'Primary Residence' | 'Secondary / Vacation' | 'Investment Property';

export interface Borrower {
  fullName: string;
  email: string;
  phone: string;
  ssnMasked: string; // e.g. ***-**-4912
  ficoScore: number;
  employer: string;
  jobTitle: string;
  yearsEmployed: number;
  monthlyBaseIncome: number;
  monthlyOtherIncome: number;
  monthlyDebts: {
    name: string;
    type: 'Auto' | 'Credit Card' | 'Student Loan' | 'Installment' | 'Other';
    monthlyPayment: number;
    balance: number;
  }[];
  liquidAssets: {
    institution: string;
    type: 'Checking' | 'Savings' | '401k/IRA' | 'Brokerage';
    amount: number;
  }[];
}

export interface PropertyDetails {
  streetAddress: string;
  city: string;
  state: string;
  zipCode: string;
  propertyType: PropertyType;
  occupancy: OccupancyType;
  purchasePrice: number;
  appraisedValue: number;
  annualPropertyTax: number;
  annualHazardInsurance: number;
  monthlyHOA: number;
}

export interface LoanTerms {
  loanAmount: number;
  downPayment: number;
  termMonths: number; // 360, 180, etc.
  interestRate: number; // e.g. 6.625
  apr: number; // e.g. 6.812
  loanType: LoanType;
  loanPurpose: LoanPurpose;
  rateLockExpiry?: string;
  isLocked: boolean;
  originationPoints: number;
}

export interface UnderwritingCondition {
  id: string;
  category: 'PTD' | 'PTC' | 'PTF'; // Prior to Doc, Prior to Closing, Prior to Funding
  title: string;
  description: string;
  status: 'pending' | 'submitted' | 'cleared' | 'waived';
  requiredDocumentName?: string;
  clearedBy?: string;
  clearedAt?: string;
}

export interface AUSEvaluation {
  system: 'Desktop Underwriter (DU)' | 'Loan Product Advisor (LPA)';
  recommendation: 'Approve/Eligible' | 'Refer/Eligible' | 'Refer/Ineligible';
  runDate: string;
  caseFileId: string;
  findings: string[];
}

export interface TridFeeItem {
  id: string;
  name: string;
  category: 'origination' | 'services_cannot_shop' | 'services_can_shop' | 'taxes_gov' | 'prepaids' | 'initial_escrow';
  toleranceCategory: 'zero' | 'ten_percent' | 'unlimited';
  loanEstimateAmount: number;
  closingDisclosureAmount: number;
  paidBy: 'Borrower' | 'Seller' | 'Lender';
}

export interface ServicingPaymentRecord {
  id: string;
  paymentDate: string;
  totalReceived: number;
  principalPortion: number;
  interestPortion: number;
  escrowPortion: number;
  lateFeePortion: number;
  principalBalanceAfter: number;
  escrowBalanceAfter: number;
  status: 'Completed' | 'Pending' | 'Reversed';
}

export interface ServicingRecord {
  servicingLoanNumber: string;
  mersMin: string;
  currentPrincipalBalance: number;
  originalBalance: number;
  interestRate: number;
  monthlyPaymentPITI: number;
  currentEscrowBalance: number;
  nextPaymentDueDate: string;
  delinquencyStatus: 'Current' | '30 Days Past Due' | '60 Days Past Due' | '90+ Days Past Due';
  daysPastDue: number;
  lastPaymentDate: string;
  paymentHistory: ServicingPaymentRecord[];
  escrowCushionTargetMonths: number;
  projectedAnnualDisbursements: {
    category: 'County Property Taxes' | 'Hazard Homeowners Insurance' | 'Flood Insurance';
    dueDate: string;
    amount: number;
  }[];
}

export interface ComplianceMetrics {
  qmStatus: 'QM Safe Harbor' | 'QM Rebuttable Presumption' | 'Non-QM';
  totalPointsAndFees: number;
  pointsAndFeesPercentage: number;
  pointsFeesCapThreshold: number; // e.g. 3.0%
  passesPointsAndFees: boolean;
  atrCompliant: boolean;
  hmdaActionTakenCode: number; // 1 = Originated, 2 = Approved not accepted, 3 = Denied, etc.
  rateSpread: number; // Spread over APOR
  censusTract: string;
  demographicsProvided: boolean;
}

export interface LoanApplication {
  id: string; // e.g. LN-2026-1049
  stage: LoanStage;
  brokerCompany: string;
  loanOfficerName: string;
  borrower: Borrower;
  property: PropertyDetails;
  terms: LoanTerms;
  aus: AUSEvaluation;
  conditions: UnderwritingCondition[];
  tridFees: TridFeeItem[];
  compliance: ComplianceMetrics;
  servicing?: ServicingRecord;
  createdAt: string;
  updatedAt: string;
  notes: {
    id: string;
    author: string;
    role: string;
    content: string;
    timestamp: string;
  }[];
}
